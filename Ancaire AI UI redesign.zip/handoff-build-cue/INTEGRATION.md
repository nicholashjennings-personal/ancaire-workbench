# INTEGRATION — wiring into the deployed lab

Target repo: `github.com/nicholashjennings-personal/ancaireai-site`, path `ancaire-ai-site-full/`. Relevant files:

- `vc-lab.js` — console controller. Owns `drawBridge(env)`, `showBuildingCue(forming)`, `clearBuildingCue()`, `drawEquity(...)`, `drawFlags(...)`, `drawMeta(...)`, `drawAssume(...)`, the SSE consumer (`consumeStream`), and the `ns()` SVG helper.
- `index.html` — carries the `#vc-lab` CSS (bars, `.vc-building`, `.vc-bld-*`, meta, equity, chips).

**Do not edit** the chat pane, header, Compile Plan, method modal, SSE/session/Turnstile logic, or any other lab (`lab.js`, `eiq-lab.js`).

The reference file's `drawBridge(t)` and cue are written in the **same SVG-DOM idiom** as the deployed `drawBridge` — porting is additive, not a rewrite.

---

## 1. EV bridge — enhance the existing `drawBridge`

The deployed `drawBridge(env)` already builds the waterfall. Apply these **additive** changes (all present in the reference):

1. **Round-increment axis.** Replace the `for (t=0..4) gv = top*t/4` gridline loop with the `niceStep`/rounded-`top` loop (SPEC → "Axis"). Label text becomes `"$" + gv + "M"`. Bump `padL` to `54` so `"$2000M"` doesn't clip.
2. **Per-lever confidence meter** under each floating bar: track + fill rect at `base+64` and `"N% underwritten"` at `base+80` (SPEC → "Labels, per column"). Move the existing "% of gain" up to `base+17` and show just `"N%"` in the lever colour.
3. **Best-case ceiling** in the risk-adjusted view: dotted gold line + left label at `Y(headlineExit)` (SPEC).
4. Keep the entry-EV datum dashed line and the connector styling as in the reference (colour = lever colour, width 2, opacity `.55*progress`).

### Animated reveal (the new part)

Deployed `drawBridge` renders instantly. Make it accept a progress arg and animate on `done`:

```js
// drawBridge(env, t)  — t in [0,1], default 1 (static)
function drawBridge(env, t){ t = (t==null?1:t); /* … build using colP(i,n,t), backOut, glow … */ }

// in consumeStream's 'done' handler, AFTER applyEnvelope stores the envelope,
// replace the single drawBridge(env) call with a short rAF ramp:
function animateBridge(env){
  var start = performance.now(), DUR = 1400;   // reveal only (cue already showed during stream)
  (function step(now){
    var t = Math.min(1, (now-start)/DUR);
    drawBridge(env, t);
    if (t < 1) requestAnimationFrame(step);
  })(performance.now());
}
```

Use `colP`, `easeOutCubic`, `easeOutBack`, the landing-glow `feGaussianBlur` filter, and value count-up exactly as in the reference. Respect `prefers-reduced-motion` → call `drawBridge(env, 1)` directly.

> The reference runs cue+reveal on one 5.6s clock for demo/loop purposes. In production the **cue** spans the live stream (variable length) and the **reveal** is the ~1.4s ramp on `done`. Keep them as two triggers.

---

## 2. Build cue — extend `showBuildingCue`

The deployed `showBuildingCue(forming)` already renders `.vc-building` with `.vc-bld-spin`, `.vc-bld-label`, and `.vc-bld-pill`s from `env.forming`. Two changes to match the approved design:

1. **Layout:** headline label on its **own line, larger** (Bricolage 22px 700), with the spinner beside it; lever pills on a **single non-wrapping row** beneath. Update the markup in `showBuildingCue` and the `.vc-bld-*` CSS in `index.html` (see below).
2. **Full-stage overlay:** the cue should cover the stage (`position:absolute; inset:0; background:rgba(10,18,15,.72); backdrop-filter:blur(3px)`), centered, and clear on `done` (existing `clearBuildingCue()` — keep it, then run `animateBridge`).

It is still driven by the real streamed `phase:'building'` event and `env.forming` lever ids — no server change.

### CSS to update in `index.html` (`#vc-lab` scope)

```css
.vc-building{ position:absolute; inset:0; z-index:6; display:flex; flex-direction:column;
  align-items:center; justify-content:center; padding:0 24px;
  background:rgba(10,18,15,.72); backdrop-filter:blur(3px); }
.vc-building .vc-bld-head{ display:flex; align-items:center; gap:12px; }
.vc-building .vc-bld-spin{ width:18px; height:18px; border-radius:50%;
  border:2px solid rgba(224,180,88,.25); border-top-color:var(--vc-accent);
  animation:vcBldSpin .7s linear infinite; flex:0 0 auto; }
.vc-building .vc-bld-label{ font-family:var(--disp); font-size:22px; font-weight:700;
  letter-spacing:-.02em; color:var(--ink); white-space:nowrap; }         /* was small/dim */
.vc-building .vc-bld-pills{ display:flex; flex-wrap:nowrap; gap:8px;
  justify-content:center; margin-top:20px; }
.vc-building .vc-bld-pill{ flex:0 0 auto; display:inline-flex; align-items:center; gap:7px;
  padding:6px 12px; border-radius:999px; border:1px solid rgba(224,180,88,.28);
  background:rgba(224,180,88,.08); color:var(--dim); font-size:11.5px; white-space:nowrap;
  animation:vcBldPill .34s ease both; }
.vc-building .vc-bld-dot{ width:8px; height:8px; border-radius:50%; flex:0 0 auto; }
@keyframes vcBldSpin{ to{ transform:rotate(360deg); } }
@keyframes vcBldPill{ from{ opacity:0; transform:translateY(4px); } to{ opacity:1; transform:none; } }
@media (prefers-reduced-motion: reduce){ .vc-building .vc-bld-spin,.vc-building .vc-bld-pill{ animation:none; } }
```

---

## 3. Read-back visuals

These map onto existing deployed functions — apply the SPEC styling only, don't restructure:

- **Equity view** (`drawEquity`): switch to the three-segment composition bar (Entry equity / EV growth / Debt paydown) with the big MOIC and legend (SPEC → "Equity view").
- **Observations** (`drawFlags` / the observations card): keep it as a card opened from the **"Observations"** chip in the levers strip (the deployed `vc-lever-strip` / `vc-oc`); render the composition bar + verdict + Area/Share/Observation table (SPEC).
- Stat cards, implied pills, deal-parameters strip, title auto-fit: style per SPEC.

---

## 4. Acceptance checklist

- [ ] Axis shows round increments (`$0M/$500M/$1000M/$1500M/$2000M`), no clipping.
- [ ] Each lever bar has a confidence meter + "N% underwritten"; "N%" of gain sits directly under the baseline.
- [ ] Risk-adjusted view shows the dotted **best-case exit** ceiling.
- [ ] On `done`, the cue clears and the bridge **sweeps in** (overshoot, landing glow, count-up); static fallback under reduced-motion.
- [ ] Build cue: large headline on its own line + single-row lever pills, full-stage overlay, driven by `phase:'building'`/`env.forming`.
- [ ] Equity view uses the composition bar; Observations opens as a card from the chip.
- [ ] **Header, chat pane, Compile Plan, method modal, and all plumbing are byte-for-byte unchanged.**
