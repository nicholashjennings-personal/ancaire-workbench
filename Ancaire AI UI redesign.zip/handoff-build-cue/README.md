# Ancaire Value Creation Lab — Build-Cue + EV-Bridge Handoff

This pack contains **only** two things to wire into the live Value Creation Lab (ancaire.ai):

1. **The rendered enterprise-value (EV) bridge** and its read-back visuals — the waterfall, stat cards, implied pills, deal-parameters strip, per-lever **confidence meters**, the best-case ceiling (risk view), the **Equity view** composition bar, the lever chips, and the **Observations** card.
2. **The build cue** — the full-stage overlay that plays while a turn streams ("Building the value bridge, sizing the levers" + the lever pills), and the **animated reveal** of the bridge when the turn finishes.

## ⛔️ Explicitly OUT of scope — do not touch

Everything else in the lab is already deployed and approved. **Do not modify, restyle, or regenerate:**

- the header / top bar (logo, "Value Creation Lab", view toggle, Compile Plan button, "Powered by AncaireAI", version)
- the **chat / console pane** (message bubbles, composer, suggestion chips, typing dots, download/reset)
- the **Compile Plan** flow / plan document
- the **"How the bridge is built"** method modal
- routing, session handling, Turnstile, SSE plumbing, `window.claude`, analytics

If a change would touch any of the above, stop and flag it. The scope is the **stage visual + the build cue only.**

## What's in this pack

| File | Purpose |
|---|---|
| `README.md` | This file — scope, boundaries, manifest |
| `SPEC.md` | Exact geometry, colours, type, timings, and per-element layout for the bridge + build cue |
| `INTEGRATION.md` | Step-by-step wiring into the deployed `vc-lab.js` / `index.html`, mapped to the real functions (`drawBridge`, `showBuildingCue`) |
| `reference/ev-bridge-and-build-cue.html` | **Runnable, self-contained vanilla HTML/JS/SVG** reproducing exactly the bridge + build cue. No framework, no build step — open it in a browser, copy the values. This is the source of truth for pixels and timing. |
| `screenshots/bridge-stage.png` | The finished bridge + read-back visuals (target state) |
| `screenshots/lever-chips.png` | The lever chips + Observations entry point |
| `screenshots/build-cue.png` | A frame of the build cue mid-stream |

## How to use it

1. Open `reference/ev-bridge-and-build-cue.html` in a browser. Hit **Replay build** to watch the cue → reveal. This is what "done" should look like.
2. Read `SPEC.md` for every constant (it matches the reference file line-for-line).
3. Follow `INTEGRATION.md` to port the two pieces into `vc-lab.js` (`drawBridge`, `showBuildingCue`) and `index.html` (CSS), leaving everything else untouched.

## Notes

- The reference is **vanilla** on purpose — it mirrors the deployed lab's own SVG-DOM style (`ns()` helpers, `drawBridge`) so the port is a near copy-paste, not a framework translation.
- Values are illustrative Project Meridian numbers. In production they come from the `done` envelope (`env.bridge`, `env.levers`, `env.deal`, `env.equityStep`); the visuals must read from those, not hard-code.
- Everything animates via `requestAnimationFrame`; a **static** bridge is simply `drawBridge(1)`.
