# SPEC — EV bridge + build cue

All constants below match `reference/ev-bridge-and-build-cue.html` exactly. Colours are the deployed `#vc-lab` palette.

## Palette / tokens

| Token | Value | Use |
|---|---|---|
| `--stage` | `#0a120f` | stage background |
| `--surface-card` | `#11201b` | stat cards, deal-params card, chips panel |
| `--surface-card-elev` | `#16271f` | modal top of gradient |
| `--field` | `#0e1a15` | pills, meter track bg, equity card |
| `--ink` | `#e8e4d8` | primary text |
| `--dim` | `#9fb0a4` | secondary text |
| `--faint` | `#809086` | labels, axis |
| `--vc-accent` | `#E0B458` | signal gold (exit bar, eyebrows, accents) |
| `--rule` | `rgba(232,228,216,.10)` | hairlines |
| `--rule-2` | `rgba(232,228,216,.18)` | stronger hairlines |

Lever colours: Commercial growth `#9AD84F`, Margin expansion `#5EBFB4`, Buy-and-build `#E0B458`, Multiple expansion `#ff7a3d`. Entry bar `#5d6f63`, Exit bar `#E0B458`.

Type: display **Bricolage Grotesque** 700 (numerals, title, headline); everything else **Hanken Grotesk** 400–700.

## Bridge geometry (SVG viewBox 720 × 486)

```
padL 54   padR 14   padT 26   padB 96   gap 16
plotH = H - padT - padB = 364        base = padT + plotH = 390
columns = [entry, ...levers, exit]   barWidth = (plotW - gap*(n-1)) / n
Y(v) = padT + plotH - (v/top)*plotH
```

**Axis — round increments only.** Do not use `top/4`. Compute a "nice" step and a rounded ceiling:

```js
niceStep(x){ p=10^floor(log10(x)); f=x/p; n = f<=1?1: f<=2?2: f<=2.5?2.5: f<=5?5:10; return n*p; }
maxV = max(exitEV, entryEV)         // + headlineExit in risk view
step = niceStep(maxV/4)             // e.g. 500 for ~1563
top  = (floor(maxV/step)+1)*step    // e.g. 2000
gridlines at 0, step, 2step … ≤ top;  label = "$" + value + "M"
```

**Entry-EV datum:** dashed line `rgba(232,228,216,.16)` `stroke-dasharray:2 4` across the plot at `Y(entryEV)` — every lever reads against it.

**Bars:** rx 5. Entry & exit rise from 0; each lever floats from the running cumulative (`lo=cum`, `hi=cum+value`). Exit bar gets `stroke rgba(224,180,88,.5)`. Lever bar opacity 0.94, entry/exit 1.

**Connectors:** from previous bar's top `(prevX2, prevY)` to this bar's base — colour = lever colour (floats) or `rgba(232,228,216,.32)`, width 2, `stroke-linecap round`, opacity `0.55 * revealProgress`.

**Labels, per column (y relative to `base`):**
- value (above bar, `Y(hi)-9`): `+$NM` for levers in lever colour, `$NM` for entry/exit; font 12 (levers) / 13.5 (ends), weight 700.
- **share of the whole gain** (`base+17`, levers only): `round(value/created*100) + "%"` in the lever colour, 11.5px bold — sits directly under the graph.
- name (`base+36` levers, 2-line via `<tspan dy=13>`; `base+20` for entry/exit): `#a9b4a6` (Exit EV in gold), 10.5–11px.
- **confidence meter** (levers only): track rect at `base+64`, width `min(barWidth*0.82, 68)`, height 5, rx 2.5, fill `rgba(232,228,216,.12)`; fill rect width `track * confidence` in the lever colour.
- `"N% underwritten"` at `base+80`, `#8f9c8c`, 9px, weight 600.

**Best-case ceiling (risk-adjusted view only):** dotted gold line at `Y(headlineExit)` (`stroke #E0B458` opacity .55, `dasharray 2 3`) + left-aligned label at `padL+6`: `"Best-case exit $" + money(headlineExit)`.

## Read-back visuals around the bridge

- **Stat cards** (4): Entry EV, Value created (`+$…`), Exit EV (gold), Uplift (`x.xx×`). `--surface-card`, 10px radius, label 9.5px uppercase faint, value 24px Bricolage 700.
- **Implied pills:** Implied EBITDA CAGR, Implied gross MOIC — pill with faint uppercase label + Bricolage value.
- **Deal parameters** card: eyebrow "Deal parameters · at entry" + pills (Revenue, EBITDA, Margin, Entry, Entry EV, Net debt *(assumed, dashed border)*, Hold).
- **Title:** single line, Bricolage 700, auto-shrunk to fit its width (start 34–40px, shrink to fit, min ~13px).
- **Equity view** card (`--field`, 12px radius): eyebrow "Equity view"; `entryEq → exitEq equity` (Bricolage, exit in gold); big MOIC (30px) top-right; a **composition bar** (height 12, radius 999, 2px gaps) of three segments — Entry equity `#5d6f63`, Enterprise-value growth `#E0B458`, Debt paydown `#5EBFB4` — summing to exit equity; legend with values.

## Lever chips + Observations (right rail panel — NOT the chat)

Panel `--field`, eyebrow "Levers · tap to inspect". One button per lever (colour chip + name + `+$NM` + `conf%`), then an **Observations** button (gold chip). Clicking a lever opens its detail card; clicking Observations opens the Observations card:

**Observations card** (modal, `border-top:3px var(--vc-accent)`): eyebrow "The read", title "Observations"; a composition bar (Operationally controllable 38% `#5EBFB4`, Integration-contingent 42% `#9AD84F`, Inorganic/buy-and-build 21% `#E0B458`); a one-line verdict; an **Area / Share / Observation** table.

## Build cue + reveal (single clock, `DUR ≈ 5600ms`, loop rest ≈ 1300ms)

Reveal progress `t ∈ [0,1]`.

- **Cue overlay** (while streaming): full-stage, `background rgba(10,18,15,.72)`, `backdrop-filter blur(3px)`. Centered column: row of **spinner** (`vcBldSpin .7s linear infinite`) + **large headline** on its own line — "Building the value bridge, sizing the levers" (Bricolage 22px 700, `--ink`, `white-space:nowrap`); then a **single non-wrapping row** of lever pills below, each fading/rising in staggered (`appear = clamp((t-(0.12+i*0.1))/0.1)`). Pill = colour dot + name, `--field`-ish gold-tinted, radius 999.
- **Cue opacity:** `t<0.4 ? 1 : clamp(1-(t-0.4)/0.08)` — fully gone by ~0.48.
- **Bar reveal:** per column `raw = easeOutCubic(clamp((t - (0.46 + i/n*0.38)) / 0.15))`; bar **height** uses `easeOutBack(raw)` (mild overshoot, `c1=1.5`); labels fade with `clamp((raw-0.55)/0.4)`; values **count up** `round(value*min(1,raw))`.
- **Landing glow:** while `0.02<raw<0.999`, a blurred halo rect (SVG `feGaussianBlur stdDeviation 5`) in the bar colour, opacity `sin(raw*π)*0.5`.
- **Exit glow:** once `raw≥0.999`, a steady soft gold halo behind the exit bar (~0.3 opacity).
- **No scan line.** (Removed — was a gimmick.)

Static render = `drawBridge(1)`.
