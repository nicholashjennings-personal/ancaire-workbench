# Handoff: Broker Follow-up Letter — Trawl Carrier Evaluation `.docx` export

## Overview
This is the reformatted **"Broker follow-up on the coverage requests"** document that the
**Trawl Carrier Evaluation** lab produces for a carrier underwriter. In the lab, the carrier
pastes a broker submission, the tool runs a Carrier Evaluation read, and the user exports a
**working-draft follow-up** they can review and adapt before sending to the broker.

The export is generated **client-side and downloaded as a `.docx`** (WordprocessingML / OOXML).
This means the file is opened later in whatever the client has installed (Microsoft Word, Google
Docs, Apple Pages, LibreOffice) **on machines that do NOT have the Ancaire brand fonts**. Every
decision below flows from that constraint.

The design in this bundle is the target look-and-feel plus the exact rules the generator must
follow. Your job is to **wire the generator to emit a `.docx` that matches this reference**, and
to implement the dynamic behavior described under *Dynamic content* and *Open items*.

## Fidelity
**High-fidelity.** Colors, type sizes, spacing, section order, and copy are all final (except the
placeholder content explicitly called out). Match them.

## About the design files
- `reference/Broker Follow-up Letter.dc.html` — the visual source of truth. It renders as a
  single US-Letter sheet. Open it in a browser to see the intended layout. **It is a design
  reference, not code to ship** — it is HTML/CSS; the deliverable is a `.docx` generator that
  reproduces this layout in OOXML.
- `reference/doc-page.js`, `reference/support.js` — runtime needed only so the `.dc.html` renders
  when you open it locally. Not part of the export.
- `reference/preview-*.png` — rendered screenshots of each zone.
- `assets/ancaire-logomark-mono-green.svg` — the mono-green logomark used in the letterhead.
- `assets/logo_512.png` — a raster fallback of the mark (see *Logo*).
- `source/broker-questions-draft-original.docx` — the ORIGINAL, unstyled export for content
  reference (extract `word/document.xml` from the zip to see the source paragraphs).

---

## THE FONT CONSTRAINT (read first)
Ancaire's brand faces (**Bricolage Grotesque** for display, **Hanken Grotesk** for body) are
**not available on the client machine** and must not be relied on in the `.docx`. Use a two-font
web-safe mapping that ships on both Windows and macOS:

| Brand role (Ancaire) | Used for | `.docx` font |
|---|---|---|
| Bricolage Grotesque / Hanken labels | Headings, eyebrows, UPPERCASE labels, the wordmark, list markers | **Arial** (fallback `Helvetica Neue`, `Helvetica`, sans-serif) |
| Hanken Grotesk | Body prose, list item text, lede, legal footer | **Georgia** (fallback `Times New Roman`, serif) |

This matches the original export, which already declares Georgia as the default and Arial for the
caps labels — so the reformat keeps the same safe stack. In OOXML set `<w:rFonts>` explicitly on
every run (`w:ascii` + `w:hAnsi`); do not inherit a theme font.

---

## Document anatomy (top to bottom)
The document is organized into **three zones**. This separation is important: only the middle zone
is meant to be pasted into an email to the broker.

### Zone A — Letterhead + notice (chrome, static)
1. **Letterhead row** — mono-green logomark (30px) + "Ancaire" wordmark (Arial 800, evergreen) on
   the left; "PHILADELPHIA · NEW YORK" (Arial 700 caps, muted) on the right.
2. **Masthead band** — full-width evergreen `#14463D` bar: "TRAWL CARRIER EVALUATION" (Arial 700
   caps, **Trawl Teal `#4CC7AC`**) left; "DECISION SUPPORT" (Arial 700 caps, `#8fb391`) right.
3. **Title** — "Broker follow-up on the coverage requests" (Arial 800, evergreen `#14463D`, one
   line — see *Open items*).
4. **Lede** — one Georgia sentence, muted.
5. **Draft-for-review notice** — cream `#EFE8DA` box, hairline border; "DRAFT FOR REVIEW" leaf-green
   label + one muted sentence.

### Zone B — Carrier reference (NOT for sending)
Everything here is carrier-internal context, above the copy boundary.
6. **Requests as submitted** — evergreen 2px top rule, heading, guidance sentence, then a paper
   `#FAF6EE` panel containing a numbered list (`<ol>`) of the **actual coverage requests extracted
   from the submission**, numbered to match the in-text references ("request 1", "requests 3 and
   4", etc.). **This content is dynamic and privacy-sensitive — see *Dynamic content*.**
7. **Refer or scrutinize before sending** — amber `#C77D2E` 2px top rule, heading (`#8A4E12`), an
   amber "CARRIER ACTION · INTERNAL — DO NOT SEND AS-IS" callout box, then the high-risk/referral
   item(s) as an amber-marked list. **Dynamic — see *Dynamic content*.**

### Copy boundary
8. A centered hairline + leaf-green label **"DRAFT MESSAGE TO BROKER — COPY FROM HERE"** marks the
   start of the pasteable message. A matching **"END OF DRAFT MESSAGE"** hairline closes it.

### Zone C — The broker message (pasteable)
9. **Subject** line.
10. **Hello,** + intro paragraph.
11. **What we need from you (Carrier to Broker)** — evergreen rule, heading, intro, numbered `<ol>`
    of items to confirm/provide.
12. **Where we can work with you** — evergreen rule, heading, intro, bulleted `<ul>` of positions.
13. **Close** — closing sentence, "Best regards,", signer name placeholder.

### Zone D — Disclaimer (static, below the message)
14. **Important disclaimer and usage guidance** — Arial caps label + the full legal disclaimer in
    small justified Georgia. Verbatim text is in the reference file; do not alter wording.

---

## Design tokens

### Colors
| Token | Hex | Used for |
|---|---|---|
| Evergreen | `#14463D` | Masthead band, section top rules, title, wordmark, numbered-list markers |
| Trawl Teal | `#4CC7AC` | "TRAWL CARRIER EVALUATION" eyebrow (**placeholder — confirm official value**) |
| Leaf green | `#487D46` | Eyebrow/label text, links, bullet markers, copy-boundary label |
| Head ink | `#15201C` | Section headings |
| Body ink | `#242C27` | Body prose, list items |
| Muted | `#566159` | Lede, intros, secondary text |
| Faint sage | `#8B968F` | Legal footer text, end-marker label |
| Paper | `#F7F1E8` | (brand ground) |
| Cream | `#EFE8DA` | Draft-notice background |
| Reference panel | `#FAF6EE` | "Requests as submitted" panel background |
| Hairline | `#E3DCCF` | Rules, box borders |
| Amber rule/marker | `#C77D2E` | Scrutinize section rule + list markers |
| Amber heading | `#8A4E12` | Scrutinize heading |
| Amber label | `#B06A1E` | Carrier-action label |
| Amber body | `#6B4A22` | Carrier-action body text |
| Amber box border | `#E7C9A8` | Carrier-action box border |
| Amber box bg | `#FBF3E8` | Carrier-action box background |
| Masthead 2nd label | `#8fb391` | "DECISION SUPPORT" |

### Type scale (px in the reference → pt for `.docx`; `w:sz` is half-points, i.e. pt × 2)
| Element | px | ≈ pt | `w:sz` | Font | Weight | Notes |
|---|---|---|---|---|---|---|
| Title (h1) | 25 | 18.5 | 37 | Arial | 800/bold | tracking −0.02em; one line |
| Section heading (h2) | 22 | 16.5 | 33 | Arial | 800/bold | tracking −0.015em |
| Wordmark | 19 | 14 | 28 | Arial | 800/bold | |
| Lede | 14 | 10.5 | 21 | Georgia | 400 | muted |
| Body / list item | 12.5 | 9.5 | 19 | Georgia | 400 | line-height 1.6 |
| Reference list item | 12 | 9 | 18 | Georgia | 400 | |
| Intro / guidance | 12 | 9 | 18 | Georgia | 400 | muted |
| Draft-notice body | 11.5 | 8.5 | 17 | Georgia | 400 | |
| Eyebrows / labels | 10 | 7.5 | 15 | Arial | 700 | UPPERCASE, tracking 0.16–0.2em |
| Boundary labels | 9 | 7 | 14 | Arial | 700 | UPPERCASE |
| Legal footer | 9.5 | 7 | 14 | Georgia | 400 | justified |

Body text is intentionally compact for a one-to-two page letter; if print readability is a concern,
bumping body to ~10.5pt is acceptable — keep the relative hierarchy.

### Spacing
- Page: US Letter, portrait, **0.85in margin** all sides.
- Section blocks: ~30–34px top margin; section rule then 14px to heading.
- List items: ~10–13px between items.

---

## `.docx` (OOXML) mapping cheat-sheet
The visual features here all have direct WordprocessingML equivalents — none of this needs images
except the logo.

- **Fonts** → `<w:rFonts w:ascii="Georgia" w:hAnsi="Georgia"/>` or `="Arial"` on every run.
- **Size** → `<w:sz w:val="…"/>` (half-points, see table).
- **Color** → `<w:color w:val="14463D"/>` (no `#`).
- **Bold** → `<w:b/>`. **Caps** → `<w:caps/>`. **Letter-spacing/tracking** → `<w:spacing w:val="N"/>`
  in twentieths of a point (e.g. 0.18em at 7.5pt ≈ 27).
- **Band / box fills** (masthead, cream notice, paper panel, amber box) → paragraph or single-cell
  table shading: `<w:shd w:val="clear" w:fill="14463D"/>`. Use a 1-cell table for the boxes so the
  fill + padding + border behave predictably; put the label + body as paragraphs in the cell.
- **Section top rules** (2px evergreen / amber) → `<w:pBdr><w:top w:val="single" w:sz="16"
  w:color="14463D"/></w:pBdr>` on the heading block (sz is eighths of a point: ~16 ≈ 2px). Hairline
  boundaries → `w:sz="6" w:color="E3DCCF"`.
- **Numbered list** ("Requests as submitted", "What we need") → real `numId` in `numbering.xml`,
  `w:numFmt="decimal"`. **Set the marker color** in the level's `<w:rPr><w:color w:val="14463D"/>`
  so numbers render evergreen (CSS `::marker` does not survive export — this must be in the numbering
  definition).
- **Bulleted list** ("Where we can work with you") → `w:numFmt="bullet"`, marker color leaf `487D46`;
  the scrutinize list uses amber `C77D2E`.
- **Justified footer** → `<w:jc w:val="both"/>`.
- **Superscript** (if the M² mark ever appears) → `<w:vertAlign w:val="superscript"/>`.

### Lists MUST paste cleanly into email
The carrier copies **Zone C** out of the `.docx` and pastes it into Outlook/Gmail. Use **native
numbered/bulleted lists** (real `<ol>`/`<ul>` → real Word list paragraphs). Do **not** fake list
markers with tables, tab stops, or manual "1." text + flex layout — those paste as broken blocks.
Native Word lists paste as clean HTML lists in every major mail client (marker colors may drop on
paste; that is fine).

---

## Dynamic content (what the generator fills in)
Static chrome (letterhead, masthead, draft notice, boundary labels, legal footer) is fixed. The rest
comes from the Carrier Evaluation read:

| Field | Source |
|---|---|
| "Requests as submitted" list | **The actual coverage requests, extracted verbatim from the broker submission the carrier pasted.** Number them to match the references used in the message body. |
| "What we need from you" items | The carrier's confirm/provide questions from the read |
| "Where we can work with you" items | The carrier's positions from the read |
| "Refer or scrutinize" section | Any items the read flags as referral / high-risk / resist / scrutinize (see below) |
| Subject | Derived from the submission / read |
| Signer name | User field; defaults to "[Your name]" |

The list content in the reference file for "Requests as submitted" is **inferred placeholder text**
consistent with the letter's references — replace it with the real extracted requests.

### Referral / high-risk rule
When the read flags any request as **referral, high-risk, resist, or scrutinize**, the generator
must:
1. Pull those item(s) OUT of the broker-facing "Where we can work with you" list.
2. Place them in the **"Refer or scrutinize before sending"** section in **Zone B (above the copy
   boundary)**, preceded by the amber **"CARRIER ACTION · INTERNAL — DO NOT SEND AS-IS"** callout
   instructing the carrier to evaluate closely and secure senior/committee sign-off before releasing
   any position on them.
3. Keep this content **out of the pasteable Zone C** so it is never sent to the broker by accident.

If there are no flagged items, omit the section (and its rule) entirely.

---

## ⚠ Open items / decisions needed
1. **Export the actual requests + privacy-policy conflict (ACTION REQUIRED).** The
   "Requests as submitted" section requires the generator to **read the actual submission content
   and reproduce the coverage requests verbatim in the export.** This **conflicts with the current
   ancaire.ai privacy policy**, which restricts retaining/reproducing pasted submission content.
   **For now: proceed with exporting the actual requests and knowingly set the privacy-policy
   conflict aside** — implement the extraction. Flag the conflict as a known, unresolved item to be
   reconciled with the privacy policy before this ships to production; do not let it block the build.
2. **Trawl Teal is a placeholder** (`#4CC7AC`). Confirm/replace with the official Trawl teal and,
   ideally, define it as a named token (`--trawl-teal`) so it stays consistent across exports.
3. **Title on one line.** The reference forces the title to one line at ~18.5pt. In `.docx`, size
   the title so it fits one line at the 0.85in-margin text width (≈6.8in), or allow a clean 2-line
   wrap — decide which.
4. **Logo format.** The letterhead uses the mono-green **SVG** (`assets/ancaire-logomark-mono-green.svg`,
   single fill `#14463D`). Word 2016+ supports embedded SVG, but Google Docs / older clients do not.
   Recommendation: **embed the SVG at export time (self-contained, vector, recolorable) with a PNG
   fallback** (`assets/logo_512.png`, or rasterize the SVG at ~120px). Drawing the SVG at runtime is
   preferred over pulling from an external asset library so the export has no network dependency.
5. **"Where we can work with you" voice.** Those items are phrased as internal strategy ("we should
   …", "use it as a visible concession"). Decide whether they are broker-facing (rephrase before
   send) or should also live in Zone B. Currently they sit in the pasteable Zone C as-is.
6. **In-text vs list numbering.** The message references original request numbers (1–7), which map to
   "Requests as submitted", NOT to the 1–6 "What we need" list. Keep the two numbering schemes
   distinct when populating content.

## Files
- `reference/Broker Follow-up Letter.dc.html` — visual source of truth (open in a browser)
- `reference/preview-01-header.png` … `preview-04-footer.png` — rendered zones
- `assets/ancaire-logomark-mono-green.svg`, `assets/logo_512.png` — logo + raster fallback
- `source/broker-questions-draft-original.docx` — original unstyled export (content reference)
