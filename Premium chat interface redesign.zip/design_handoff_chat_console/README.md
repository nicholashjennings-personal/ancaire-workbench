# Handoff: AncaireAI Premium Chat Console

## Overview
A redesign of the **AncaireAI chat console** — the conversation panel that appears in every
Ancaire Lab (M², E-IQ, Value Creation, Trawl). The goal was to make the chat feel more *premium*:
richer depth and layered surfaces, refined typography and hierarchy, tasteful motion (streaming
replies, message arrivals, ambient glow), more tactile controls, and a clearer AncaireAI presence.

One console shell is shared across all four labs. It re-themes to each lab's accent color; only the
accent, greeting, suggestion chips, and placeholder change per lab. Everything else is identical.

**In scope for this pack:** the console header, the message log (bot + user bubbles), the "thinking"
indicator, suggestion chips, and the composer (input + send + "Powered by AncaireAI" footer).

**Explicitly out of scope (excluded on request):** the "route this thread to a human partner"
toggle, the handoff acknowledgement modal, and the summary-email pack. Do not build those from this
document.

## About the design files
The file in this bundle (`AncaireAI-Console.dc.html`) is a **design reference created in HTML** — a
working prototype showing the intended look and behavior. It is **not production code to copy
directly.** The task is to **recreate this design in the target codebase's existing environment**
(React, Vue, Svelte, native, etc.) using its established components, state patterns, and libraries.
If no front-end environment exists yet, choose the most appropriate framework and implement it there.

The prototype is authored in a lightweight in-house component runtime; ignore that scaffolding
(`support.js`, the `<x-dc>` wrapper, `{{ }}` template holes, `sc-for`/`sc-if`, `renderVals`). What
matters is the markup structure, the inline styles, the copy, and the interaction logic — all
documented below so you can build from this README alone.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, shadows, motion, and copy are final. Recreate
the UI pixel-accurately using the codebase's own libraries. Values are given as exact tokens below.

---

## The console — layout

A single vertical flex column, fixed height `600px`, `width: 420px` (in the real product it is a
resizable panel docked to the right of the lab; default width 400px). Structure top to bottom:

```
┌─────────────────────────────────────────┐
│  HEADER  (lab-accent gradient band)       │  fixed
├─────────────────────────────────────────┤
│  MESSAGE LOG  (scrolls, masked edges)     │  flex: 1
│    • bot bubble  (avatar + text)          │
│    • user bubble (accent, right-aligned)  │
│    • thinking indicator (3 dots)          │
├─────────────────────────────────────────┤
│  SUGGESTED  label + chip row              │  fixed
├─────────────────────────────────────────┤
│  COMPOSER  textarea + send button         │  fixed
│  "Powered by AncaireAI" footer band       │
└─────────────────────────────────────────┘
```

Console container:
- `border: 1px solid var(--rule-strong)`, `border-radius: 16px`, `overflow: hidden`
- `background: linear-gradient(180deg, var(--panel-2), var(--surface))`
- `box-shadow: 0 40px 100px rgba(0,0,0,.6), 0 30px 100px -50px var(--lab-glow), inset 0 1px 0 rgba(232,228,216,.07)`
- Sits inside a `position: relative` wrapper that also holds an **ambient glow**: an absolutely
  positioned blurred radial of `var(--lab-glow)` (`inset: -28px; filter: blur(46px); opacity: .34`)
  that slowly breathes (`ancBreathe`, 6.5s). Purely decorative, `pointer-events: none`.

### Header (fixed, ~62px)
- `background: linear-gradient(180deg, var(--lab-head-1), var(--lab-head-2))` — a darkened tint of
  the lab accent (see per-lab table). `border-bottom: 1px solid rgba(232,228,216,.12)`,
  `box-shadow: inset 0 1px 0 rgba(255,255,255,.09)`, `padding: 14px 16px`.
- A slow diagonal **light sheen** sweeps across it: an absolutely positioned skewed white-gradient
  strip animating left→right (`ancSheen`, 7.5s), clipped by the header's `overflow: hidden`.
- **Avatar medallion** (left): 34×34, `border-radius: 9px`,
  `background: linear-gradient(150deg,#1f6355,#123c34)`, `1px solid rgba(232,228,216,.16)` border,
  `inset 0 1px 0 rgba(255,255,255,.1)` highlight. Holds the reverse logomark (18px). A **green
  "online" status dot** (10px, `#7cc08a`, 2px `var(--lab-head-2)` ring) sits bottom-right and pulses
  (`ancPulseGreen`, 2.6s). NOTE: the status dot is **always green** in every lab — green signals
  "AncaireAI is live," it is not the lab accent.
- **Title block:** "AncaireAI" in Bricolage Grotesque 600, 15.5px, `#f4f0e7`. Subtitle in Hanken
  11px `rgba(232,228,216,.72)`: `"<lab> Lab guide · "` + `online` (the word "online" is `#7cc08a`).
- **Action icons** (right): download, expand, reset, minimize — 30×30 ghost buttons, stroked SVG
  (Lucide/Feather style, `stroke-width 2.2`, round caps), `rgba(232,228,216,.72)`. Hover:
  `background: rgba(255,255,255,.1); color: #f4f0e7`. These are presentational in the prototype.

### Message log (flex: 1, scrolls)
- `padding: 20px 16px`, `display: flex; flex-direction: column; gap: 16px`, `overflow: auto`.
- Top and bottom edges softly fade via
  `-webkit-mask-image: linear-gradient(180deg, transparent 0, #000 20px, #000 calc(100% - 6px), transparent 100%)`.
- Auto-scrolls to the bottom on every new message / streamed token.
- Custom scrollbar: 8px, thumb `var(--rule-strong)`, transparent track.

**Bot bubble:** a row of `avatar (26px) + bubble`, left-aligned, `gap: 10px`.
- Avatar: 26×26, same green-gradient medallion as the header, logomark 13px.
- Bubble: `max-width: 84%`, `background: linear-gradient(180deg, var(--panel-3), var(--panel))`,
  `border: 1px solid var(--rule)`, `border-radius: 4px 15px 15px 15px` (notched top-left toward the
  avatar), `padding: 12px 15px`, text `var(--ink)` 14.5px / line-height 1.58,
  `box-shadow: inset 0 1px 0 rgba(232,228,216,.05), 0 10px 26px rgba(0,0,0,.3)`.
- While streaming, a blinking caret follows the text: a 2px×15px `var(--lab)` bar, `ancCaret` 0.9s.

**User bubble:** right-aligned, no avatar.
- `max-width: 82%`, `background: linear-gradient(180deg, var(--lab-head-1), var(--lab-head-2))`
  (the lab-accent darkened tint — so the user's bubble carries the lab's color),
  `border: 1px solid var(--lab-soft)`, `border-radius: 15px 15px 4px 15px` (notched bottom-right),
  `padding: 12px 15px`, text `#f4f0e7` 14.5px / 1.58,
  `box-shadow: inset 0 1px 0 rgba(255,255,255,.08), 0 10px 26px rgba(0,0,0,.32)`.

**Every bubble animates in** with `ancMaterialize` (0.5s, `cubic-bezier(.2,.7,.2,1)`): fade + rise
12px + scale 0.97→1 + blur 6px→0.

**Thinking indicator:** shown after the user sends, before the reply streams. Same avatar (pulsing
green) + a bot-style bubble containing three 6px `var(--lab)` dots bouncing in sequence
(`ancBlink`, 1s, staggered 0 / .15s / .3s).

### Suggested chips (fixed)
- A `"Suggested"` uppercase label (10px, `.16em`, `var(--ink-faint)`) above a wrapping chip row
  (`gap: 8px`).
- Chip: `display: inline-flex; align-items: center; gap: 7px`, `padding: 8px 13px`,
  `border-radius: 999px`, `border: 1px solid var(--rule)`,
  `background: linear-gradient(180deg, var(--panel), var(--surface))`, `color: var(--ink-dim)`,
  12.5px, `box-shadow: inset 0 1px 0 rgba(232,228,216,.03)`. A 5px `var(--lab)` dot (opacity .7)
  leads the label.
- Chips stagger in on lab change (`ancChip`, 0.5s, delay `index * 0.07s`).
- Hover: `color: var(--ink); border-color: var(--lab); transform: translateY(-1px); box-shadow: 0 5px 16px rgba(0,0,0,.32)`.
- Clicking a chip sends its question as a user message.

### Composer (fixed)
- Top rule `1px var(--rule)`, `padding: 12px 14px 13px`,
  `background: linear-gradient(180deg, transparent, rgba(11,19,16,.5))`.
- Row: auto-growing `<textarea>` + send button, `gap: 10px`, `align-items: flex-end`.
- Textarea: `flex: 1`, `min-height: 48px`, `max-height: 120px`, `resize: none`,
  `background: var(--panel-2)`, `border: 1px solid var(--rule-strong)`, `border-radius: 12px`,
  `padding: 12px 14px`, **`font-size: 16px`** (keep 16px so iOS does not zoom), line-height 1.4.
  Focus: `border-color: var(--lab); box-shadow: 0 0 0 3px var(--lab-soft)`. Placeholder text is
  per-lab and uses `var(--ink-faint)`. Grows with content up to the max, then scrolls.
- Send button: 44×44, `border-radius: 12px`, `background: var(--lab)`, icon color `#0c1512`
  (up-arrow, stroked SVG), `box-shadow: 0 5px 16px var(--lab-glow), inset 0 1px 0 rgba(255,255,255,.25)`.
  Has an idle breathing glow (`ancSendGlow`, 3.6s). Hover `filter: brightness(1.08)`; active
  `transform: scale(.93)` (press response, per house rule: color/scale shift, no bounce).
- **Footer band** (full-width, replaces the earlier floating tag): `border-top: 1px solid var(--rule)`,
  centered, `background: rgba(232,228,216,.015)`, holding the reverse logomark (12px, opacity .55) +
  `"POWERED BY ANCAIREAI"` (10px, `.16em`, uppercase, `var(--ink-faint)`). It is inset to the panel
  edges (negative horizontal margin) so its top rule spans the full console width.

---

## Interactions & behavior

- **Send** (button click, or Enter without Shift): trim input; if empty, no-op. Append a user
  bubble, clear the input, reset the textarea height, and show the thinking indicator.
- **Reply**: after ~950ms the thinking indicator is replaced by an empty bot bubble that **streams**
  word by word at ~46ms per word, with the blinking caret until complete.
- **Reply content**: if the sent text exactly matches a suggestion chip's question, use that chip's
  scripted answer; otherwise use the lab's generic fallback line. (In production, replace this with a
  real AncaireAI/Claude call that streams tokens; the UI already assumes token-by-token streaming.)
- **Lab switch**: selecting a lab in the switcher re-themes the console via CSS variables, clears the
  log, and reseeds it with that lab's greeting. Any in-flight timers are cancelled.
- **Auto-scroll**: the log pins to the bottom on every update.
- **Reduced motion**: honor `prefers-reduced-motion` — disable `ancBreathe`, `ancSheen`,
  `ancSendGlow`, `ancMaterialize`, and the streaming caret; render replies instantly.
- **Shift+Enter** inserts a newline (does not send).

## State
- `lab`: one of `m2 | eiq | vc | trawl` (drives all theming + content).
- `msgs`: ordered list of `{ role: 'bot' | 'user', text, streaming: boolean }`.
- `input`: current textarea value.
- `thinking`: boolean (show the dots indicator).
- Transient timers: one reply-delay timeout, one streaming interval. Clear both on lab switch /
  unmount.

---

## Design tokens

All visual values come from the **Ancaire Labs Design System** (dark "instrument console" theme).
Pull these from the codebase's existing token layer if present; otherwise define them.

### Base palette (CSS custom properties, from the design system)
| Token | Value | Use |
|---|---|---|
| `--surface` | `#0c1512` | app canvas / console base gradient bottom |
| `--panel` | `#11201b` | raised panel step 1 |
| `--panel-2` | `#16271f` | raised panel step 2 (console top, textarea) |
| `--panel-3` | `#1b3128` | raised panel step 3 (bot bubble top) |
| `--ink` | `#e8e4d8` | primary warm-cream text |
| `--ink-dim` | `#9fb0a4` | secondary text |
| `--ink-faint` | `#809086` | labels, placeholders |
| `--rule` | `rgba(232,228,216,.10)` | hairline separators |
| `--rule-strong` | `rgba(232,228,216,.18)` | control borders |
| `--accent` | `#14463d` | firm deep green (filled surfaces) |
| `--accent-text` | `#7cc08a` | links, focus, live states |

### Per-lab theming
Each lab sets four variables. `--lab-head-1/2` is a darkened accent tint used for the header band
**and** the user bubble.

| Lab | `--lab` (accent) | `--lab-soft` | `--lab-glow` | `--lab-head-1` | `--lab-head-2` |
|---|---|---|---|---|---|
| M² | `#7cc08a` | `rgba(124,192,138,.16)` | `rgba(124,192,138,.5)` | `#185a4d` | `#123c34` |
| E-IQ | `#ff7a3d` | `rgba(255,122,61,.16)` | `rgba(255,122,61,.5)` | `#8a3a18` | `#4a1e0c` |
| Value Creation | `#E0B458` | `rgba(224,180,88,.16)` | `rgba(224,180,88,.5)` | `#6f5324` | `#3d2c10` |
| Trawl | `#5EBFB4` | `rgba(94,191,180,.16)` | `rgba(94,191,180,.5)` | `#155650` | `#0c3734` |

The green medallion gradient `linear-gradient(150deg,#1f6355,#123c34)` and the green online dot
`#7cc08a` are constant across all labs (AncaireAI's identity), independent of the lab accent.

### Typography (design system)
- **Display** (`--font-display`): **Bricolage Grotesque** — used only for the "AncaireAI" title.
- **Sans** (`--font-sans`): **Hanken Grotesk** — everything else.
- Sizes here: title 15.5px/600; bubble & input 14.5–16px/1.58; subtitle 11px; chip 12.5px; uppercase
  labels 10px. Tracking: `.16em` on uppercase labels, `.01–.04em` on UI text.

### Radius
5–9px small controls · 12px inputs/buttons/chip-medallions · 15–16px bubbles & console · `999px` chips.

### Shadow / motion
- Console `0 40px 100px rgba(0,0,0,.6)` + accent ambient glow. Bubbles `0 10px 26px rgba(0,0,0,.3)`.
- Transitions `.16s` controls, `.18s` chips, `.5s` bubble entrance. Easing `cubic-bezier(.2,.7,.2,1)`.
- Keyframes to recreate: `ancMaterialize` (bubble in), `ancChip` (chip in), `ancBlink` (thinking
  dots), `ancCaret` (streaming caret), `ancPulseGreen` (status dot), `ancBreathe` (ambient glow),
  `ancSheen` (header sheen), `ancSendGlow` (send button idle glow). Definitions are in the prototype's
  `<style>` block.

## Assets
- `assets/ancaire-logomark-reverse.svg` — the white/reverse AncaireAI logomark, used in the header
  medallion, the bot avatars, and the composer footer. Included in this bundle. Use the brand's real
  logomark from your asset pipeline; do not redraw it.
- All icons (download / expand / reset / minimize / send / arrow) are inline stroked SVGs in the
  Lucide/Feather style (`viewBox 0 0 24 24`, `fill none`, `stroke currentColor`, `stroke-width ~2.2`,
  round caps/joins). Reuse your existing icon set matching that style.

## Files
- `AncaireAI-Console.dc.html` — the high-fidelity prototype (open in a browser to interact: type,
  send, switch labs, watch replies stream). Markup, inline styles, copy, and logic are all here.
- `assets/ancaire-logomark-reverse.svg` — logomark asset.

### Design-system note
The prototype links the Ancaire Labs Design System stylesheet for its color/type tokens. In the
prototype folder this resolves via the project's `_ds/` directory; in the target codebase, map the
tokens above onto your own design-system layer rather than linking the prototype's stylesheet.
