# Handoff: Ancaire Labs — Portal Picker + Lab Cards redesign

## Overview
This redesigns the **"choose your agent" section** of the Ancaire Labs portal (ancaire.ai landing page). It replaces the old full-width stacked lab rows with:

1. A **natural-language picker hero** ("Bring the work. We'll hand you the right agent.") — a type-to-match input plus use-case chips that route the visitor to the right lab in one keystroke.
2. A **2×2 grid of lab cards** (M², E-IQ, Trawl, Value Creation) at equal visual weight, each with a live animated "instrument" glyph in a recessed well, a status chip, description, and metadata.

> **SCOPE — READ FIRST.** Only the **picker section** and the **lab cards grid** are in scope. **Do NOT touch the existing site header/topbar or the footer.** The prototype reproduces a top band and a bottom "Rather talk it through?" block **only for visual context** — they already exist in production and must be left as-is. Wire in the two middle sections and nothing else.

## About the Design Files
`Lab Cards.dc.html` is a **design reference authored in HTML**, not production code to paste in. It uses an internal component runtime (custom `<x-dc>`, `{{ }}` template holes, `<sc-if>`, `<sc-for>`, `<x-import>`) that will **not** exist in the target codebase — ignore that machinery and **recreate the markup, styling, animations, and matching logic** in the app's real environment (the ancaire.ai site; from the source it is a static/vanilla site with inline CSS, so plain HTML/CSS/JS is the natural target — match whatever the existing portal page uses).

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii, shadows, copy, and animation timings are final. Recreate pixel-for-pixel. Every value needed is listed below; you should not have to guess.

---

## The critical requirement: the Trawl card may be hidden

Production uses **middleware/config that selectively shows or hides the Trawl Lab card** (it is an invite-only preview and is not shown to everyone). The prototype always renders all four cards, so **you must decide how the layout and picker behave when Trawl is absent.** Handle all of it:

**1. The 2×2 grid becomes 3 cards.** `grid-template-columns: 1fr 1fr` with 3 children leaves a lopsided hole (2 on top, 1 orphaned bottom-left). Pick one and apply consistently:
   - **Preferred:** when only 3 cards are visible, render a **1×3 row on desktop** (`grid-template-columns: repeat(3, 1fr)`), collapsing to 2-up / 1-up at narrower widths. This keeps all three at equal weight with no gap.
   - Acceptable alternative: keep the 2-column grid but center the trailing card, or promote one card to span both columns. The orphaned-hole layout is **not** acceptable.
   - Drive this off the **same server flag** that hides Trawl — render the grid with a modifier (e.g. `data-count="3"`) rather than detecting it client-side.

**2. The picker's matcher must not route to a hidden lab.** The keyword matcher includes Trawl (`policy`, `insurance`, `clause`, `coverage`, `contract`, `gap`, `claim`, `structured`, `reading`). If Trawl is hidden:
   - **Exclude Trawl from the candidate list** the matcher searches, so a visitor describing an insurance/coverage question is **not** matched to a lab that isn't on the page. Build the lab list from the same visibility source that controls the cards — never hardcode all four.
   - A query that would only have matched Trawl should fall through to the **"No match on that yet…"** state, which already tells the visitor to describe it differently or pick from the labs below. (Do not point them at a `#lab-trawl` anchor that isn't rendered.)
   - The "Read policy coverage gaps" **use-case chip** must also be **omitted** when Trawl is hidden (it presets a Trawl-only query). Build the chip list from visible labs too.

**3. Anchor links.** Each card's Enter CTA and each picker match navigate via `#lab-<id>` hash to the card. If a lab is hidden its anchor must not be referenced anywhere. Keep anchor id and visibility in sync from one source of truth.

Treat lab visibility as a single server-provided list (`visibleLabs`) that drives the grid, the matcher candidates, and the chips together. The design must look and behave correctly for **either 4 visible labs or 3** (and ideally any subset — the same reasoning applies if another lab is ever gated).

---

## Screens / Views

There is one view: the portal "choose your agent" section. Two sub-sections in scope, described below. Overall page: dark canvas `--surface` (`#0c1512`), content centered in a `max-width: 1180px` column with `0 40px` horizontal padding and `64px` bottom padding. Body carries two faint radial glows (see Design Tokens › Background).

### Section A — Picker hero
- **Purpose:** Visitor types what they're running; the UI matches it to a lab and offers an Enter CTA. Chips offer preset use cases.
- **Layout:** vertical stack, `margin: 52px 0 20px`.
  - **Kicker:** "Ancaire Labs · powered by AncaireAI" — 11px, uppercase, letter-spacing `.22em`, color `--ink-faint`, `margin-bottom: 16px`.
  - **Headline (h1):** "Bring the work. We'll hand you the right agent." — display font (Bricolage Grotesque), 700, **48px**, line-height 1.03, letter-spacing `-.025em`, `max-width: 15ch`, `text-wrap: balance`, `margin: 0 0 16px`.
  - **Subhead (p):** "Live labs, each AncaireAI pointed at one job. Tell us what you're running and we point you to the right one in a keystroke." — 16.5px, line-height 1.55, color `--ink-dim`, `max-width: 58ch`, `margin: 0 0 28px`.
  - **Input row** (wrapper `max-width: 780px`): flex row, `gap: 10px`, background `linear-gradient(180deg, var(--panel-2), var(--panel))`, `1px solid var(--rule-strong)`, `border-radius: 14px`, `padding: 8px 8px 8px 22px`, `box-shadow: 0 18px 50px rgba(0,0,0,.4)`.
    - **`<input>`**: flex:1, transparent, no border/outline, color `--ink`, body font, **17px**, `padding: 15px 0`. Placeholder: "Describe an initiative you have in flight…".
    - **Submit `<button>`** (aria-label "Match to a lab"): 50×50px, `border-radius: 11px`, no border, background `--accent` (`#14463d`), glyph `→` in `#eafff0` at 21px, `transition: .16s`; hover `filter: brightness(1.14)`. Also fires on **Enter** key in the input.
  - **Matched result** (only when a match exists, appears below the input, `margin-top: 14px`): flex row, `gap: 18px`, `padding: 15px 16px 15px 20px`, same panel gradient, `border: 1px solid <lab.accent>`, `border-radius: 13px`.
    - Left column: label "Matched on" (10px, uppercase, `.16em`, `--ink-faint`); lab name (display font, 700, 19px, letter-spacing `-.01em`, color = lab accent); reason line (13.5px, `--ink-dim`, `margin-top: 3px`).
    - **Enter CTA `<a href="#lab-...">`**: inline-flex, `gap: 8px`, body font 600 14px, `padding: 12px 20px`, `border-radius: 10px`, text `#0a120f`, background = lab accent. Label "Enter →".
  - **No-match state** (query non-empty and nothing matched): `<p>` `margin: 15px 2px 0`, 13.5px, line-height 1.5, `--ink-faint`: "No match on that yet. Describe the situation another way, or pick from the labs below."
  - **Use-case chips row:** flex, `gap: 9px`, wrap, `margin-top: 24px`. Leading label "Or pick a use case" (11px, uppercase, `.14em`, `--ink-faint`, `margin-right: 4px`). Each chip is a `<button>`: background `rgba(232,228,216,.04)`, `1px solid var(--rule-strong)`, `border-radius: 999px`, color `--ink-dim`, body font 13px, `padding: 8px 15px`, `transition: .16s`; hover `border-color: var(--accent-text); color: var(--ink)`. Clicking a chip fills the input with the chip's preset query and re-runs the match.

### Section B — Section heading + cards grid
- **Section heading block:** `margin: 44px 0 28px; padding-top: 30px; border-top: 1px solid var(--rule)`.
  - Kicker "The labs" — 11px, uppercase, `.22em`, color `--accent-text`, `margin-bottom: 12px`.
  - **h2** "Pick the agent that fits the work." — display font 700, 32px, letter-spacing `-.02em`, line-height 1.05, `text-wrap: balance`.
- **Grid:** `display: grid; grid-template-columns: 1fr 1fr; gap: 22px`. Four cards in DOM order: **M² Lab, E-IQ Lab, Trawl Lab, Value Creation Lab** (see the Trawl-hidden rules above for the 3-card case).

### The lab card (one component, four instances)
Root is an `<a id="lab-<id>" href="#">` (whole card is the click target):
- `position: relative; display: flex; flex-direction: column`.
- Background `linear-gradient(180deg, var(--panel-2), var(--panel))`, `border: 1px solid var(--rule-strong)`, `border-radius: 16px`, `box-shadow: 0 18px 50px rgba(0,0,0,.5)`, `overflow: hidden`, `color: inherit`, `transition: .22s`.
- **Hover:** `border-color: <accent>; transform: translateY(-4px); box-shadow: 0 30px 70px rgba(0,0,0,.6)`.

**Instrument well** (top of card): `position: relative; height: 158px; background: #0a120f`, plus an accent radial glow `background-image: radial-gradient(130% 150% at 80% 22%, <accent at ~.14–.15 alpha>, transparent 60%)`, `border-bottom: 1px solid var(--rule)`, `overflow: hidden`.
- **Kicker label** (absolute, `top: 16px; left: 20px`): 11px, uppercase, letter-spacing `.18em`, weight 600, color = accent. Text per card below.
- **Animated SVG glyph** (`viewBox="0 0 260 260"`, `fill="none"`, absolutely positioned, right-aligned, vertically centered, `opacity: .85`, sized per card). Details in Interactions.

**Body:** `display: flex; flex-direction: column; gap: 14px; padding: 24px; flex: 1`.
- **Title h2:** display font 700, 27px, letter-spacing `-.02em`, line-height 1.1, color `--ink`. (M² uses a `<sup>` for the ².)
- **Status chip** (`align-self: flex-start`, `margin-top: -2px`, `border-radius: 999px`, `padding: 5px 11px`, 10.5px, uppercase, `.1em`, weight 600). Two kinds:
  - **Available now** (M², E-IQ): color = accent, background = accent at 10% (`<hex>1a`), border = accent at ~35% (`<hex>59`); leading **6×6px dot** in accent that **pulses** (see Interactions). `display: inline-flex; align-items: center; gap: 7px`.
  - **Invite-only preview** (Trawl, VC): color `--ink-faint`, background `rgba(232,228,216,.05)`, `border: 1px solid var(--rule-strong)`, no dot. Text: "Invite-only preview".
  - Chips are toggleable as a group (prototype prop `statusChips`); in production show them always unless product decides otherwise.
- **Description `<p>`:** 15px, line-height 1.55, color `--ink-dim`, `flex: 1` (pushes footer down). Copy per card below.
- **Metadata block:** 11.5px, letter-spacing `.02em`, color `--ink-faint`, line-height 1.7. Two lines; the label span ("Practice Owner:", "Scope:", "For:") is color `--ink-dim`. Copy per card below.
- **Enter link (inline):** inline-flex, `gap: 9px`, weight 600, 15px, color = accent, with a trailing `→` (16px). Hover widens `gap` to 13px.

#### Per-card content

| Card | id | Accent | Well kicker | Title | Status |
|---|---|---|---|---|---|
| M² Lab | `lab-m2` | `#7cc08a` (mint) | The framework | M² Lab | Available now |
| E-IQ Lab | `lab-eiq` | `#ff7a3d` (orange) | The diagnostic | E-IQ Lab | Available now |
| Trawl Lab | `lab-trawl` | `#5EBFB4` (teal) | The instrument | Trawl Lab | Invite-only preview |
| Value Creation Lab | `lab-vc` | `#E0B458` (gold) | Where the value is | Value Creation Lab | Invite-only preview |

**M² Lab** — description: "A live, interactive map of Ancaire's M² operating framework: the four pillars and the principles, components, and instruments beneath them. Ask about any part and it lights up, or describe a real program and watch it land on the framework." Metadata: "Practitioner depth · complex programs" / "**Practice Owner:** Strategic Execution". Enter label: "Enter the M² Lab →".

**E-IQ Lab** — description: "The Execution Intelligence Quotient reads how well an initiative is set up to deliver. Describe a program, project, integration, or launch and it scores six execution dimensions into a single E-IQ, with the reasoning behind each. A live radar builds as you talk." Metadata: "General audience · anyone running real work" / "**Practice Owner:** Strategic Execution". Enter label: "Enter the E-IQ Lab →".

**Trawl Lab** — description: "Point it at the right kind of question and it returns a careful, structured read, with its reasoning shown as it works. The scope is deliberately narrow today and widens toward general availability in 2027." Metadata: "Invite-only preview · narrow-scope structured reading, GA 2027" / "**Practice Owner:** Strategic Execution". Enter label: "Enter the Trawl Lab →". ⚠️ **Trawl's Practice Owner was not present in the live-site source (that render had Trawl hidden) — "Strategic Execution" is a placeholder; confirm the correct practice before shipping.**

**Value Creation Lab** — description: "For middle-market PE and M&A: describe a business or a deal and the lab builds a value-creation plan, rendered as a live enterprise-value bridge from entry to exit that you reshape as you talk." Metadata: "Invite-only preview · Financial Sponsors, PE firms, Operating Partners" / "**Practice Owner:** M&A Advisory". Enter label: "Enter the Value Creation Lab →".

**All four cards now carry a Practice Owner line** as their second metadata line (matching the available cards): M² → Strategic Execution, E-IQ → Strategic Execution, Trawl → Strategic Execution *(placeholder, confirm)*, VC → M&A Advisory.

---

## Interactions & Behavior

### Picker matching logic
- State: a single `query` string bound to the input.
- On each input change (and on submit / Enter / chip click) compute a match: lowercase-trim the query, then return the **first** lab (in list order) that has any keyword `included` in the query string. If none, `null`.
- Lab keyword sets (lowercase substring match):
  - **M² Lab** → `framework, m2, m², operating, methodology, governance, maturity, mobiliz, measurement, pillar, model, program, complex`
  - **E-IQ Lab** → `execution, ready, readiness, deliver, integration, launch, project, score, diagnostic, risk, on track, stuck, rollout, transformation, initiative, e-iq, eiq`
  - **Value Creation Lab** → `value, pe, private equity, m&a, deal, ebitda, acquisition, exit, bridge, sponsor, portfolio, buyout, revenue, margin, multiple, investment, operating partner`
  - **Trawl Lab** → `policy, insurance, clause, coverage, contract, structured, reading, gap, claim`  *(exclude entirely when Trawl is hidden — see the Trawl-hidden section)*
- Match reasons (shown in the result row): M² "Map a complex program onto the M² operating framework." · E-IQ "Score how well the initiative is set up to deliver." · VC "Build a value-creation plan and a live enterprise-value bridge." · Trawl "Return a careful, structured read of a narrow question."
- `matched` truthy → render result row with Enter CTA linking to `#lab-<id>`. `query` non-empty && no match → render no-match line. Empty query → neither.
- Submit button / Enter key: if matched, set `window.location.hash = '#lab-<id>'` (smooth-scrolls to the card). Use whatever navigation the real site prefers, but keep it a same-page anchor to the card.
- **Order matters:** list order is M², E-IQ, VC, Trawl. Note `m&a` matches VC (before Trawl). Preserve this precedence when you rebuild the candidate list.

### Use-case chips (label → preset query)
- "Understand the M² framework" → `understand the M² operating framework` (→ M²)
- "Is my program on track?" → `score how ready my program is to deliver` (→ E-IQ)
- "Post-merger integration" → `post-merger integration execution` (→ E-IQ)
- "A PE value-creation plan" → `private equity value creation plan for a deal` (→ VC)
- "Read policy coverage gaps" → `insurance policy coverage gap reading` (→ Trawl; **omit chip when Trawl hidden**)

Clicking a chip sets `query` to its preset and lets the same match logic run (result row updates).

### Animations (the instrument glyphs)
All are ambient loops. **Respect `prefers-reduced-motion: reduce` — disable them all** (the prototype kills every animation under that media query). CSS-keyframe animations honor a motion on/off toggle via `animation-play-state`; SMIL ones (below) do not — if you need a global motion switch, gate SMIL by not rendering the `<animate*>` elements. Keyframes used:
- `ancOrbit` / `ancOrbitRev` / `ancRotate`: linear 360° rotation (one reversed).
- `ancPulse`: `0/100% { opacity:.25; transform:scale(.82) } 50% { opacity:1; transform:scale(1.32) }` (used for glyph accent dots and the status-chip live dot).

**M² Lab — orrery (168×168).** Three concentric rings, each in a `<g>` that rotates about the **true center**: set `transform-box: view-box; transform-origin: 130px 130px` (NOT `fill-box`/`center` — that pivots on the group's bounding box and makes dots drift off their ring). Each ring carries one or two accent "planet" dots positioned exactly on the ring radius (r=108, r=74, r=40 about center 130,130) so they orbit locked to the ring. Outer ring `ancOrbit 22s`, middle `ancOrbitRev 15s`, inner `ancRotate 30s reverse`. A central 6.5px cream dot (`#ece7da`) pulses with `ancPulse 4s` (slow heartbeat).

**E-IQ Lab — radar (164×164).** Two faint static hex outlines (outer + mid). The **data polygon** is a 6-vertex radar that **morphs** — each axis value changes over time, redrawing the shape like a live radar (NOT a scale pulse). Implemented with SMIL `<animate attributeName="points">`, `dur="9s"`, `calcMode="spline"`, 5 keyframes (last = first for a seamless loop), ease-in-out splines. The 6 spokes radiate from center (130,130) along unit vectors `[0,-1] [.866,-.5] [.866,.5] [0,1] [-.866,.5] [-.866,-.5]` at radius ≈ 90×value; the file lists the exact per-frame point sets you can copy. Fill `rgba(255,122,61,.18)`, stroke `#ff7a3d` at .85, `stroke-width 2.4`, `stroke-linejoin: round`. One 4px apex dot pulses (`ancPulse 2s`). (There is intentionally **no** rotating sweep line.)

**Value Creation Lab — EV bridge bars (164×164).** A baseline line at y=214 and four vertical bars that **grow and shrink in place** (NOT bounce/translate) — like a live enterprise-value bridge resizing. Each `<rect>` sits on the baseline (bottom fixed at y=214) and animates its `height` **and** `y` together via two synchronized SMIL `<animate>` elements, `calcMode="spline"`, ease-in-out, 5 keyframes (first=last). Staggered durations 6.5s / 7.5s / 7s / 8s. Bars at x=44/90/136/182, width 30, `rx 3`, gold fills at increasing alpha (.1/.16/.22/.14), strokes `#E0B458`. Exact height/y value arrays are in the file.

**Trawl Lab — plumb bob in water (150×150).** Three faint net arcs (static). A **fixed anchor dot** (3.5px teal at 130,52) is the top pivot. Below it, a `<g>` holds the plumb line (130,52 → 130,150) and the bob polygon. The motion must read like a weight suspended in deep water — **loose, smooth, non-stiff** — built from compound, out-of-phase SMIL transforms:
  - Outer `<g>`: two `additive="sum"` `<animateTransform>` — a slow **rotate** about the anchor (130,52), `dur="19s"`, 13 irregular keyframes (asymmetric angles ±~12°), ease-in-out splines; plus a gentle **translate** buoyant drift, `dur="11s"`, ~2px, different period so it never locks.
  - Inner `<g>` around the bob polygon only: a smaller **rotate** about the bob's top joint (130,150), `dur="7s"`, `begin="-2s"` (phase offset), so the weight trails/lags the line like drag in water.
  - All splines are smooth `0.4 0 0.6 1` ease-in-out so velocity eases to near-zero at each turn (no jerk). Exact keyTimes/values are in the file — copy them.

### Hover states (summary)
- Card: lifts 4px, border → accent, deeper shadow.
- Enter inline link: `gap` 9px → 13px.
- Submit button: `brightness(1.14)`.
- Chips: border → `--accent-text`, text → `--ink`.
- All transitions `.16s`–`.22s`, no bounce (house rule).

## State Management
- `query: string` — the picker input value; drives `matched` (object | null) and `showNoMatch` (bool) as derived values.
- `visibleLabs` — **server/middleware-provided** list of which labs render. Single source of truth for: the cards rendered, the grid column count / layout modifier, the matcher candidate list, and the chip list. (Prototype hardcodes all four; production must not.)
- `motion` (optional): global toggle for ambient animation (prototype prop). If you expose it, gate CSS animations via `animation-play-state` and SMIL by conditional render.
- No data fetching beyond the visibility flag; matching is pure client-side string logic.

## Design Tokens
Pull these from the existing Ancaire Labs design system where the site already defines them (CSS custom properties). Literal values, from `tokens/colors.css`:
- **Surfaces:** `--surface #0c1512` (canvas), well/stage `#0a120f`, `--panel`/`--panel-2` panel-gradient stops (raised: `#11201b → #16271f → #1b3128` family).
- **Ink:** `--ink #e8e4d8` (warm cream), `--ink-dim` (sage), `--ink-faint` (`#809086`).
- **Accent:** `--accent #14463d` (filled buttons / console), `--accent-text #7cc08a` (links, live states).
- **Rules:** `--rule rgba(232,228,216,.10)`, `--rule-strong rgba(232,228,216,.18)`.
- **Lab accents:** M² `#7cc08a`, E-IQ `#ff7a3d`, VC `#E0B458`, Trawl `#5EBFB4`. Chip tints derive as `<hex>1a` (10% bg) and `<hex>59` (~35% border).
- **Background glows (body):** `radial-gradient(120% 90% at 22% 0%, rgba(124,192,138,.06), transparent 55%)` + `radial-gradient(90% 90% at 100% 100%, rgba(20,70,61,.22), transparent 60%)`.
- **Type:** display = **Bricolage Grotesque** (700; titles/headings only, `--font-display`); body/UI/labels = **Hanken Grotesk** (`--font-sans`). Sizes used: 48 (hero h1), 32 (section h2), 27 (card title), 22 (footer h3, out of scope), 17 (input), 16.5 (subhead), 15 (Enter link / body), 14 (Enter CTA), 13.5 (reasons/no-match), 13 (chips), 11.5 (metadata), 11 (kickers), 10.5 (status chip), 10 ("Matched on"). Letterspacing: `.22em` wide kickers, `.18em` well kickers, `.16em`/`.14em`/`.1em` small labels, `-.02em`/`-.025em` display.
- **Radii:** cards 16, wells inherit, input 14, match row 13, submit 11, CTA/enter 10, chips/status/dots 999px.
- **Shadows:** card `0 18px 50px rgba(0,0,0,.5)`, card hover `0 30px 70px rgba(0,0,0,.6)`, input `0 18px 50px rgba(0,0,0,.4)`.
- **Timing:** controls `.16s`, cards/overlays `.22s`; ambient loops per glyph above.

## Assets
- `assets/ancaire-logomark-reverse.svg` — reverse (near-white) logomark, used in the top band (top band is **out of scope / already in production**; asset included only because the prototype references it). Use the existing production asset.
- All glyphs are **inline SVG drawn in code** (no image/icon files). Copy the SVG markup from `Lab Cards.dc.html`.
- Fonts (Bricolage Grotesque, Hanken Grotesk) load via the design system's `tokens/fonts.css` — use the site's existing font setup.

## Files
- `Lab Cards.dc.html` — the full design reference (picker + grid + the out-of-scope band/footer for context). All exact SVG markup, animation keyTimes/values, and copy live here. The internal-runtime bits (`<x-dc>`, `{{ }}`, `<sc-if>`, `<sc-for>`, `<x-import>`, and the `<script type="text/x-dc">` logic class) are **not** portable — read them as a spec and reimplement in the target app.
- `assets/ancaire-logomark-reverse.svg` — logomark referenced by the prototype.

### Reading the prototype's runtime (translation key)
- `{{ x }}` — a value/handler binding. `{{ pstate }}` = `'running'|'paused'` for `animation-play-state`; `{{ statusDisp }}` = `'inline-flex'|'none'` for chip visibility; `{{ matched.* }}`, `{{ query }}`, `{{ chip.* }}` = the picker state above.
- `<sc-if value="{{ matched }}">` / `<sc-if value="{{ showNoMatch }}">` — conditional blocks (render when truthy).
- `<sc-for list="{{ chips }}" as="chip">` — repeat over the chips array.
- `style-hover="…"` — a hover style (translate to `:hover` CSS).
- `<x-import component-from-global-scope="…Button">` (footer) — a design-system Button; **out of scope**.
- The `<script type="text/x-dc" data-dc-script>` class `Component` holds the match logic, keyword sets, chip presets, and match reasons — the authoritative source for the behavior section.
