/* ============================================================
   Ancaire — Waves. The ancaire.co / ancaire.ai ambient-strands field:
   stacked, flowing horizontal bands rendered in a single WebGL fragment
   shader (no deps). A color ramp runs up the stack like a rainbow of firm
   greens; gentle sine wobble + swell give the slow flowing-wave motion.

   Ported from ancaire-ai-site-full/strands.js (the "baked physics from
   ancaire.co") and generalized into an init() so any canvas can host it.

   Usage:
     AncaireWaves.init(canvasEl, {
       bg:'#0e3a32',
       ramp:['#14463d','#2e8b73','#88c050','#cfe8b0'], // dark→apex
       strands:18, opacity:0.5, spread:0.40, depth:1.0, bleed:0.4,
       structure:0.75, speed:1.4, glow:0.4, fps:30
     });
   Honors prefers-reduced-motion (one still frame) and pauses when hidden.
   ============================================================ */
(function (global) {
  function init(canvas, opts) {
    if (!canvas) return { stop() {} };
    var o = Object.assign({
      bg: '#0e3a32',
      ramp: ['#14463d', '#2e8b73', '#88c050', '#cfe8b0'],
      strands: 18, opacity: 0.5, spread: 0.40, depth: 1.0, bleed: 0.40,
      structure: 0.75, speed: 1.4, glow: 0.4, fps: 30,
    }, opts || {});
    var reduce = global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches;

    var gl;
    try { gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl'); } catch (e) {}
    if (!gl) return { stop() {} };

    var vert = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.0,1.0);}';
    var frag = [
      'precision highp float;',
      'uniform float uTime,uSpeed,uStrands,uOpacity,uSpread,uDepth,uBleed,uStructure,uGlow;uniform vec2 uRes;',
      'uniform vec3 cDark,cAcc,cMid,cApex,cBg;',
      'float hash(float n){return fract(sin(n)*43758.5453);}',
      'vec3 ramp(float t){t=clamp(t,0.0,1.0);',
      ' vec3 c=mix(cDark,cAcc,smoothstep(0.0,0.34,t));',
      ' c=mix(c,cMid,smoothstep(0.30,0.66,t));',
      ' c=mix(c,cApex,smoothstep(0.62,1.0,t));',
      ' return c;}',
      'void main(){',
      ' vec2 uv=gl_FragCoord.xy/uRes;',
      ' float u=uv.x+uv.y*0.30;',
      ' float t=uTime*uSpeed;',
      ' float NFLOW=3.0;',
      ' vec3 field=vec3(0.0); float wsum=0.0; float cover=0.0;',
      ' int N=int(uStrands);',
      ' for(int i=0;i<90;i++){',
      '   if(i>=N)break;',
      '   float fi=float(i);',
      '   float flow=mod(fi,NFLOW);',
      '   float fph=flow*2.2 + t*0.30;',
      '   float jitter=hash(fi)*2.0-1.0;',
      '   float base=0.26+0.48*(flow/(NFLOW-1.0));',
      '   float depth=hash(fi+3.1);',
      '   float focus=mix(1.0,0.30,depth*uDepth);',
      '   float bright=mix(1.0,0.55,depth*uDepth);',
      '   float wob=0.105*sin(u*3.3+fph)+0.044*sin(u*6.1+fph*1.5)+0.017*sin(u*10.2-fph*0.7);',
      '   float swell=0.125*sin(u*2.3+fph)+0.038*sin(u*4.5+fph*1.0)+0.015*sin(u*7.4+fph*0.6);',
      '   float center=base + jitter*uSpread*0.16 + mix(wob,swell,uStructure);',
      '   float w=(0.004+0.003*hash(fi+7.0))/focus;',
      '   float d=(uv.y-center)/w;',
      '   float strand=exp(-d*d*0.7)*bright;',
      '   float along=0.5+0.5*sin(u*1.6+fph+jitter*mix(1.2,0.5,uStructure));',
      '   float g=clamp(along*0.75+0.16,0.0,1.0);',
      '   vec3 sc=ramp(g);',
      '   field+=sc*strand; wsum+=strand; cover+=strand;',
      ' }',
      ' vec3 strandCol = wsum>0.0 ? field/wsum : cBg;',
      ' float a=clamp(cover*uOpacity*(1.0+uBleed*0.6),0.0,1.0);',
      ' vec3 col=mix(cBg,strandCol,a);',
      ' col += strandCol * clamp(cover,0.0,1.6) * uGlow;',
      ' gl_FragColor=vec4(col,1.0);',
      '}'].join('\n');

    function sh(type, src) {
      var s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) return null;
      return s;
    }
    var vs = sh(gl.VERTEX_SHADER, vert), fs = sh(gl.FRAGMENT_SHADER, frag);
    if (!vs || !fs) return { stop() {} };
    var prog = gl.createProgram(); gl.attachShader(prog, vs); gl.attachShader(prog, fs); gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return { stop() {} };
    gl.useProgram(prog);

    var buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    var pl = gl.getAttribLocation(prog, 'p'); gl.enableVertexAttribArray(pl); gl.vertexAttribPointer(pl, 2, gl.FLOAT, false, 0, 0);

    function U(n) { return gl.getUniformLocation(prog, n); }
    var uTime = U('uTime'), uRes = U('uRes');
    var isMobile = global.innerWidth < 760;
    gl.uniform1f(U('uSpeed'), o.speed);
    gl.uniform1f(U('uStrands'), isMobile ? Math.min(o.strands, 14) : o.strands);
    gl.uniform1f(U('uOpacity'), o.opacity);
    gl.uniform1f(U('uSpread'), o.spread);
    gl.uniform1f(U('uDepth'), o.depth);
    gl.uniform1f(U('uBleed'), o.bleed);
    gl.uniform1f(U('uStructure'), o.structure);
    gl.uniform1f(U('uGlow'), o.glow);
    function col(n, hex) { hex = hex.replace('#', ''); gl.uniform3f(U(n), parseInt(hex.substr(0, 2), 16) / 255, parseInt(hex.substr(2, 2), 16) / 255, parseInt(hex.substr(4, 2), 16) / 255); }
    col('cBg', o.bg);
    col('cDark', o.ramp[0]);
    col('cAcc', o.ramp[1]);
    col('cMid', o.ramp[2]);
    col('cApex', o.ramp[3]);

    var dpr = 1;
    function resize() {
      var r = canvas.getBoundingClientRect();
      dpr = Math.min(global.devicePixelRatio || 1, 1.75);
      var w = Math.max(1, r.width), ht = Math.max(1, r.height);
      canvas.width = Math.round(w * dpr); canvas.height = Math.round(ht * dpr);
      gl.viewport(0, 0, canvas.width, canvas.height);
      gl.uniform2f(uRes, canvas.width, canvas.height);
    }
    resize();
    var rt; function onResize(){ clearTimeout(rt); rt = setTimeout(function(){ resize(); requestAnimationFrame(resize); }, 120); }
    global.addEventListener('resize', onResize);
    if (global.ResizeObserver) { try { new ResizeObserver(onResize).observe(canvas); } catch(e){} }

    function draw(tt) { gl.uniform1f(uTime, tt); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4); }
    if (reduce) { draw(12.0); return { stop() {} }; }

    var raf = 0, last = 0, tt = 0, frameMs = 1000 / o.fps;
    function loop(now) {
      raf = global.requestAnimationFrame(loop);
      if (now - last < frameMs) return;
      last = now; tt += 0.016; draw(tt);
    }
    function start() { if (!raf) { last = 0; raf = global.requestAnimationFrame(loop); } }
    function stop() { if (raf) { global.cancelAnimationFrame(raf); raf = 0; } }
    document.addEventListener('visibilitychange', function () { if (!document.hidden) start(); else stop(); });
    start();
    return { stop: stop };
  }

  global.AncaireWaves = { init: init };
})(window);
