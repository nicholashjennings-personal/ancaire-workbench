/* Ancaire Labs — Pre-Lab Intro Loop · framework-agnostic reference controller.
 *
 * Reproduces the exact behavior of `Ancaire Lab Intro.dc.html` without the prototype's
 * DC runtime. Wire it to static markup carrying the hooks noted in README §6, then adapt
 * to React/Vue as the site requires. Transitions live in CSS (see the block at the bottom).
 */
(function () {
  // ---- config ----
  const SCHEDULE = [3750, 11500, 20000, 28500, 32750]; // ms → beat becomes active
  const AUTO_END = 37750;                               // ms → finish()/handoff
  const HANDOFF_FADE = 1200;                            // ms before navigating
  const NEXT_URL = 'index.html';                        // ← the existing launch screen (see README §Integration)
  const CONTACT_URL = 'https://ancaire.co/engage.html';
  const NAVIGATE_ON_END = true;                         // false = stop at handoff / remove overlay instead

  const root = document.getElementById('intro-root');
  if (!root) return;
  const scenes    = [...root.querySelectorAll('[data-scene]')].sort((a, b) => a.dataset.scene - b.dataset.scene);
  const fill      = root.querySelector('#intro-progress-fill');
  const pausedEl  = root.querySelector('#intro-paused');
  const pill      = root.querySelector('#intro-pill');
  const introEl   = root.querySelector('#intro-overlay');
  const handoffEl = root.querySelector('#intro-handoff');
  const canvas    = root.querySelector('#intro-canvas');

  let beat = 0, phase = 'intro', paused = false;
  let t0 = 0, elapsedPaused = 0, timers = [], prog = null, handoff = null, wave = null;

  // ---- wave field (E-IQ orange colorway) ----
  if (window.AncaireWaves && canvas) {
    wave = window.AncaireWaves.init(canvas, {
      bg: '#0a1310', ramp: ['#14463d', '#2e8b73', '#cf7a2e', '#f6b85a'],
      strands: 20, opacity: 0.55, spread: 0.42, depth: 1.0,
      bleed: 0.45, structure: 0.7, speed: 1.5, glow: 0.45, fps: 30,
    });
  }

  // ---- render (imperative; mirror in your framework's render) ----
  function render() {
    scenes.forEach((el, i) => {
      const on = i === beat, past = i < beat;
      el.style.opacity = on ? '1' : '0';
      el.style.transform = 'translateY(' + (on ? '0px' : past ? '-26px' : '26px') + ')';
      el.style.filter = 'blur(' + (on ? '0px' : '8px') + ')';
    });
    if (pill)      { pill.style.opacity = beat === 5 ? '0' : '1'; pill.style.pointerEvents = beat === 5 ? 'none' : 'auto'; }
    if (pausedEl)  pausedEl.style.opacity = (paused && phase === 'intro') ? '1' : '0';
    if (introEl)   { introEl.style.opacity = phase === 'intro' ? '1' : '0'; introEl.style.pointerEvents = phase === 'intro' ? 'auto' : 'none'; }
    if (handoffEl) { handoffEl.style.opacity = phase === 'intro' ? '0' : '1'; handoffEl.style.pointerEvents = phase === 'intro' ? 'none' : 'auto'; }
  }

  // ---- timeline ----
  function clearTimers() {
    timers.forEach(clearTimeout); timers = [];
    if (prog) { clearInterval(prog); prog = null; }
    if (handoff) { clearTimeout(handoff); handoff = null; }
  }
  function scheduleFrom(elapsed) {
    clearTimers();
    t0 = Date.now() - elapsed;
    SCHEDULE.forEach((ms, i) => {
      const d = ms - elapsed;
      if (d > 0) timers.push(setTimeout(() => { beat = i + 1; render(); }, d));
    });
    timers.push(setTimeout(() => { if (phase === 'intro') finish(); }, Math.max(0, AUTO_END - elapsed)));
    prog = setInterval(() => {
      if (phase !== 'intro' || paused) return;
      if (fill) fill.style.width = Math.min(100, ((Date.now() - t0) / AUTO_END) * 100) + '%';
    }, 200);
  }

  // ---- actions ----
  function pause() {
    if (phase !== 'intro' || paused) return;
    elapsedPaused = Math.min(AUTO_END, Date.now() - t0);
    clearTimers(); paused = true; render();
  }
  function resume() { if (!paused) return; paused = false; render(); scheduleFrom(elapsedPaused || 0); }

  function finish() {
    if (phase === 'handoff') return;
    clearTimers(); phase = 'handoff';
    if (fill) fill.style.width = '100%';
    render();
    if (!NAVIGATE_ON_END) { handoff = setTimeout(() => root.remove(), HANDOFF_FADE); return; }
    handoff = setTimeout(() => { try { window.location.assign(NEXT_URL); } catch (e) { replay(); } }, HANDOFF_FADE);
  }
  function replay() {
    clearTimers(); beat = 0; phase = 'intro'; paused = false;
    if (fill) fill.style.width = '0%';
    render(); scheduleFrom(0);
  }
  function contact(e) { if (e && e.preventDefault) e.preventDefault(); clearTimers(); window.open(CONTACT_URL, '_blank'); }

  // ---- wire controls ----
  root.querySelectorAll('[data-intro-finish]').forEach((b) => b.addEventListener('click', finish));
  root.querySelectorAll('[data-intro-contact]').forEach((b) => b.addEventListener('click', contact));
  root.querySelectorAll('[data-intro-replay]').forEach((b) => b.addEventListener('click', replay));

  // hidden press-and-hold to pin/pause
  document.addEventListener('pointerdown', pause);
  document.addEventListener('pointerup', resume);
  document.addEventListener('pointercancel', resume);
  window.addEventListener('blur', resume);

  // teardown hook (call on unmount): clearTimers(); if (wave) wave.stop();

  render();
  scheduleFrom(0);
})();

/* --- Companion CSS (put in your stylesheet) ---
#intro-root [data-scene] {
  transition: opacity .9s cubic-bezier(.2,.8,.2,1),
              transform .9s cubic-bezier(.2,.8,.2,1),
              filter .9s cubic-bezier(.2,.8,.2,1);
}
#intro-overlay, #intro-handoff { transition: opacity 1.1s cubic-bezier(.2,.8,.2,1); }
#intro-pill { transition: color .2s, opacity .5s cubic-bezier(.2,.8,.2,1); }
#intro-progress-fill { transition: width .4s linear; }
@keyframes anc-orbit  { from { transform: rotate(0) } to { transform: rotate(360deg) } }
@keyframes anc-breathe{ 0%,100% { transform: scale(1); opacity:.55 } 50% { transform: scale(1.06); opacity:1 } }
@keyframes anc-aurora { 0%,100% { transform: translate3d(-3%,-2%,0) scale(1.05) }
                        33% { transform: translate3d(4%,3%,0) scale(1.12) }
                        66% { transform: translate3d(2%,-4%,0) scale(1.08) } }
@media (prefers-reduced-motion: reduce) {
  #intro-root [data-scene], #intro-overlay, #intro-handoff { transition: none; }
  .anc-aurora, .anc-orbit { animation: none !important; }
}
--- */
