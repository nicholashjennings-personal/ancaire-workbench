# Handoff: Ancaire Labs — Pre‑Lab Cinematic Intro Loop (ancaire.ai)

## Overview
A full‑screen, cinematic **intro loop** that plays on launch of **ancaire.ai**. It’s a ~38‑second
gated experience that gives a first‑time visitor a brief, atmospheric overview of what Ancaire Labs is
and what it offers, then **hands off to the existing launch screen** (`index.html`). It runs over the
Ancaire green/orange **wave field** (WebGL strands) with a lime signal accent, matching the firm’s
Direction 03 (“Engineered”) language.

It exists to set context and tone before the app UI appears — think of it as a title sequence. Returning
or impatient visitors can **Skip** immediately.

## About the Design Files
The files in this bundle are a **design reference created in HTML** — a working prototype showing the
intended look, motion, timing, and behavior. **It is not production code to ship as‑is.** The task is to
**recreate this experience in ancaire.ai’s real codebase** using its established environment and patterns.

The prototype was authored as a “Design Component” (a small custom `<x-dc>` runtime with `{{ }}` template
holes and a `renderVals()` logic class). **Do not port that runtime.** Section 6 gives a plain, framework‑
agnostic controller that reproduces the exact behavior; use it as the reference implementation and adapt to
React/Vue/vanilla as the site requires. The real ancaire.ai site is a vanilla static site
(`github.com/nicholashjennings-personal/ancaire-site`) with `ds.css`, `waves.js`, and injected chrome via
`ds-chrome.js` — implement this as a vanilla page/overlay there.

## Fidelity
**High‑fidelity.** Final colors, typography, spacing, copy, motion, and interactions. Recreate the visuals
pixel‑faithfully using the site’s existing design tokens (`ds.css`) and the `waves.js` shader. All exact
values are documented below and visible in `Ancaire Lab Intro.dc.html`.

---

## Structure at a glance

The experience has **two phases** in one full‑viewport `.anc-lab` dark container:

1. **`intro`** — six cross‑fading “beats” (scenes) over the wave field, with a progress bar, persistent
   Skip + “Talk to us” controls, and a hidden press‑and‑hold pause.
2. **`handoff`** — a brief breathing‑logomark frame (“Entering Ancaire Labs”) that then navigates to
   `nextUrl` (`index.html`).

Fixed layers, back to front (all `position:absolute; inset:0` unless noted):
1. `<canvas>` — the wave field (WebGL).
2. **Aurora glow** — drifting radial green/lime glow, `mix-blend-mode:screen`, `opacity:0.55`, `inset:-20%`.
3. **Scrim** — `radial-gradient(130% 100% at 50% 42%, rgba(6,13,10,0.42) 0%, rgba(6,13,10,0.66) 54%, rgba(4,9,7,0.93) 100%)`.
4. **Letterbox vignette** — `linear-gradient(180deg, rgba(4,9,7,0.72) 0%, rgba(4,9,7,0) 16%, rgba(4,9,7,0) 84%, rgba(4,9,7,0.78) 100%)`.
5. **Intro layer** (`z-index:10`) — the six scenes + Skip + pill + paused cue + progress bar.
6. **Handoff layer** (`z-index:20`) — logomark + “Entering Ancaire Labs” + Replay.

---

## Timeline & motion

```
SCHEDULE (ms from load, when each beat becomes active) = [3750, 11500, 20000, 28500, 32750]
  beat 0  0 – 3.75s      brand reveal
  beat 1  3.75 – 11.5s   welcome
  beat 2  11.5 – 20s     what this is
  beat 3  20 – 28.5s     what’s inside
  beat 4  28.5 – 32.75s  signature diptych
  beat 5  32.75 – 37.75s step inside (CTA)
AUTO_END = 37750         → finish() → handoff → navigate
handoff fade before navigate = 1200ms
```

- **Scene cross‑fade:** each scene transitions `opacity .9s`, `transform .9s`, `filter .9s`, easing
  `cubic-bezier(0.2,0.8,0.2,1)` (the brand ease, `var(--ease)`).
  - Active scene: `opacity:1; translateY(0); blur(0)`.
  - Not‑yet‑shown: `opacity:0; translateY(26px); blur(8px)`.
  - Already‑past: `opacity:0; translateY(-26px); blur(8px)`.
- **Phase fade** (intro ↔ handoff): `opacity 1.1s var(--ease)`.
- **Progress bar** fill width updates on a 200ms interval; `transition: width .4s linear`.
- **Ambient keyframes:**
  - `anc-orbit` — 6s linear infinite; the ring around the brand‑reveal logomark.
  - `anc-breathe` — `0/100%: scale(1) opacity .55; 50%: scale(1.06) opacity 1`; handoff logomark uses
    it at 2.2s.
  - `anc-aurora` — 26s ease‑in‑out infinite; slow translate/scale drift of the aurora glow.
- **Reduced motion:** `@media (prefers-reduced-motion: reduce)` disables `anc-aurora` and `anc-orbit`.
  Also, when `document.hidden`, all scene/phase transitions are set to `none` so a backgrounded tab
  doesn’t freeze mid‑fade (they snap to the correct state). Re‑enable on `visibilitychange`.

---

## Screens / Views (beats)

All scenes are centered (`display:flex; flex-direction:column; align-items:center; justify-content:center`),
full‑bleed, `text-align:center` unless noted. Eyebrows are Hanken 12px/700, `text-transform:uppercase`,
`letter-spacing:0.3em`, color lime (`#9AD84F`), `white-space:nowrap`.

### Beat 0 — Brand reveal
- 96×96 box; a `border-radius:50%` ring `inset:-14px`, `1px solid var(--rule-2)` with
  `border-top-color: lime`, spinning via `anc-orbit 6s linear infinite`.
- Center: `ancaire-logomark-reverse.svg`, 64×64.
- Below (gap 26px): eyebrow **“Ancaire Labs”**, `letter-spacing:0.34em`, `font-size:13px`, lime.

### Beat 1 — Welcome
- Eyebrow **“Welcome to”**.
- H1 (Bricolage 800, `letter-spacing:-0.035em`, `line-height:0.93`, `font-size:clamp(48px,8.5vw,124px)`,
  color `#f3f8f1`, `white-space:nowrap`): **“Ancaire Labs”**.
- Lede (Hanken, `clamp(17px,1.7vw,22px)`, `line-height:1.55`, color `#f3f8f1`, `max-width:680px`):
  “The firm’s working surface, where Ancaire’s frameworks and senior judgment become something you can
  explore and use, not just read.”
- gap 22px; horizontal padding `0 8vw`.

### Beat 2 — What this is
- Eyebrow **“What this is”**.
- A register list, `max-width:940px`, `border-top:2px solid #f3f8f1`. Each row:
  `display:grid; grid-template-columns:minmax(0,210px) 1fr; gap:28px; align-items:baseline;
  padding:22px 4px; border-bottom:1px solid var(--rule-2)`.
  - Row label (Bricolage 700, `letter-spacing:-0.03em`, `clamp(26px,3vw,42px)`, `#f3f8f1`) + body
    (Hanken, `clamp(15px,1.4vw,19px)`, `line-height:1.5`, `#f3f8f1`):
    - **Live** — “Our methods and models, rendered as systems you can interrogate, not static slideware.”
    - **Guided** — “AncaireAI works alongside you, translating your situation into the firm’s thinking.”
    - **Senior‑led** — “Built by the practitioners who lead the engagements, and held to the same standard: execution.”

### Beat 3 — What’s inside
- Eyebrow **“What’s inside”**.
- 3‑column grid, `max-width:1040px`, `grid-template-columns:repeat(3,1fr); gap:1px;
  background:var(--rule-2); border:1px solid var(--rule-2)` (the 1px gaps + bg create hairline dividers).
  Each cell: `background:#0a1310; padding:26px 24px; display:flex; flex-direction:column; gap:12px`.
  - Title (Bricolage 700, `letter-spacing:-0.025em`, `line-height:1.1`, **`min-height:2.2em`** to reserve
    two lines so bodies align, `clamp(22px,2.2vw,30px)`, `#f3f8f1`) + body (Hanken 15px, `line-height:1.5`,
    color `var(--dim)`):
    - **Interactive frameworks** — “The M² operating model and our diagnostics, rendered as live maps you can walk through.”
    - **Scenario tooling** — “Pressure‑test a transformation, an integration, or a value‑creation plan against how we actually run them.”
    - **Working briefs** — “Turn a conversation with AncaireAI into a board‑ready brief before it reaches a partner.”
- Closing line below grid (Hanken, `clamp(15px,1.5vw,19px)`, `#15201C`/`var(--ink)`, `max-width:680px`,
  centered): “Because the fastest way to understand how we work **is to use it.**” — the phrase “is to use
  it.” is lime (`#9AD84F`), non‑italic (`font-style:normal`).

### Beat 4 — Signature diptych (firm ↔ lab)
A mirrored two‑column composition contrasting the firm’s line with the lab’s.
- Container: `display:grid; grid-template-columns:1fr 1px 1fr; align-items:center;
  gap:clamp(28px,5vw,72px); max-width:1120px; position:relative`.
- **Balance axis** (absolute, behind): full‑width 1px line at `top:50%`,
  `background:linear-gradient(90deg, rgba(154,216,79,0) 0%, var(--rule-2) 22%, var(--rule-2) 78%, rgba(154,216,79,0) 100%)`.
- **Duality glows** (absolute, behind): left `radial-gradient(closest-side, rgba(201,212,203,0.07), transparent)`,
  right `radial-gradient(closest-side, rgba(154,216,79,0.10), transparent)`; each `width:42%; height:120%`.
- **Left (firm, subordinated), right‑aligned** (`align-items:flex-end; text-align:right; gap:18px`):
  - Eyebrow **“The firm”**, color `var(--dim)` (`#566159`).
  - Line (Bricolage 800, `line-height:0.95`, `clamp(30px,4.4vw,64px)`, color `#c9d4cb`):
    “Execution,” / “engineered**.**” (`<br>`; period lime).
  - Descriptor (Hanken 13px/600, `letter-spacing:0.02em`, `var(--dim)`): “how the work gets done”.
- **Center divider:** the middle `1px` grid track, `align-self:stretch; background:var(--rule-2)`. (No dot.)
- **Right (lab, foreground), left‑aligned** (`align-items:flex-start; text-align:left; gap:18px`):
  - Eyebrow **“The lab”**, color lime.
  - Line (Bricolage 800, `clamp(30px,4.4vw,64px)`, color `#f3f8f1`): “Complexity,” / “clarified**.**”.
  - Descriptor (Hanken 13px/600, lime): “how you make sense of it”.
- Intent: the firm’s established line (“Execution, engineered.”) sits softened on the left; the lab’s new
  line (“Complexity, clarified.”) sits brighter on the right — a subtle balance placing the lab in front.

### Beat 5 — Step inside (CTA)
- Eyebrow **“Step inside”**.
- H1 (Bricolage 800, `clamp(40px,6vw,88px)`, `#f3f8f1`, nowrap): **“Enter Ancaire Labs”**.
- Button row (`display:flex; gap:14px; flex-wrap:wrap; justify-content:center`):
  - **Begin** — design‑system Button, `variant=lime`, `size=lg`, arrow, onDark → triggers `finish()`.
  - **Talk to us first** — custom button: Hanken 700 17px, color `#ffffff`, `background:#14463d`,
    `border:1.5px solid #2f6e5f`, `border-radius:5px`, `height:50px`, `padding:0 24px`, gap 9px, trailing
    “→”. Hover: `background:#0e3a32; transform:translateY(-2px)` (`.2s var(--ease)`). → `contact()`.
- Caption (mono 12px, `letter-spacing:0.04em`, `var(--dim)`): “Entering automatically…”.

### Handoff frame
- Full‑bleed, `background:radial-gradient(120% 90% at 50% 45%, rgba(8,16,12,0.30) 0%, rgba(6,13,10,0.9) 70%, #060d0a 100%)`, gap 24px.
- `ancaire-logomark-reverse.svg` 58×58, `animation:anc-breathe 2.2s var(--ease) infinite`.
- Eyebrow **“Entering Ancaire Labs”** (lime).
- **Replay** pill bottom‑center (Hanken 11px/600, `var(--dim)`, transparent, `1px solid var(--rule-2)`,
  `border-radius:pill`, `padding:7px 14px`; hover color lime) → `replay()`.

---

## Persistent controls (intro phase)

- **Skip →** — top‑right (`top:24px; right:28px; z-index:12`). Pill: Hanken 12px/600, `letter-spacing:0.14em`,
  uppercase, color `#f3f8f1`, `background:rgba(15,29,24,0.55)`, `1px solid var(--rule-2)`, `border-radius:pill`,
  `padding:9px 16px`, `backdrop-filter:blur(6px)`, hover color lime → `finish()`.
- **Talk to us** — top‑left (`top:24px; left:28px; z-index:12`), same pill style, `<a href=contactUrl>` →
  `contact()`. **Hidden on beat 5** (opacity 0 / pointer‑events none) since that scene has its own contact
  button; fades via `opacity .5s`.
- **Paused cue** — bottom‑center (`bottom:32px; z-index:13`): two 3×11px lime bars (pause glyph) +
  “Paused · release to resume” (Hanken 11px/700, `letter-spacing:0.2em`, uppercase, lime). Opacity 0 unless
  paused; `transition:opacity .25s`.
- **Progress bar** — bottom edge, full width, `height:6px`, track `rgba(154,216,79,0.14)`; fill lime with
  `box-shadow:0 0 16px rgba(154,216,79,0.75)`.

---

## Interactions & Behavior

- **Auto‑advance:** timers fire each `SCHEDULE[i]` to set `beat = i+1`; at `AUTO_END`, `finish()`.
- **`finish()`** → set phase `handoff`, freeze progress at 100%, then after 1200ms navigate to `nextUrl`.
  Reference impl does a `fetch(nextUrl, {method:'HEAD'})` reachability check and, if it fails (loop running
  standalone with no launch screen), calls `replay()` to keep looping. In the real site you can drop the
  check and navigate directly, since `index.html` always exists.
- **Skip / Begin** → `finish()` immediately.
- **Talk to us / Talk to us first** → `contact()`: opens `contactUrl`
  (**`https://ancaire.co/engage.html`**) in a new tab (`window.open(url,'_blank')`) and stops the timeline.
- **Replay** (handoff) → `replay()`: reset to beat 0, phase `intro`, restart timeline.
- **Hidden press‑and‑hold to pause/pin:** `pointerdown` anywhere → `pause()` (records elapsed, clears
  timers, shows paused cue); `pointerup` / `pointercancel` / window `blur` → `resume()` (reschedules from the
  recorded elapsed time). Only active during the `intro` phase.
- **Visibility:** on `visibilitychange`, force a re‑render so transitions flip between smooth (visible) and
  instant (hidden) — prevents a backgrounded tab from freezing a half‑faded scene.

## State Management
- `beat` (0–5) — active scene.
- `phase` — `'intro' | 'handoff'`.
- `progress` (0–1) — progress‑bar fill / elapsed fraction.
- `paused` (bool) — press‑and‑hold state.
- Internal refs: `t0` (timeline start, back‑dated by elapsed on resume), `elapsedPaused`, `timers[]`,
  `progTimer`, `handoffTimer`, `waveHandle`.
- **Props / config:**
  - `nextUrl` (default `"index.html"`) — where to hand off.
  - `navigateOnEnd` (default `true`) — if false, `finish()` stops at the handoff frame and does **not**
    navigate (use this for the “overlay on the same document, then remove overlay to reveal page” pattern).
  - `contactUrl` (default `"https://ancaire.co/engage.html"`).

---

## Colorway — the E‑IQ orange strands

The wave field uses the site’s `waves.js` (`window.AncaireWaves.init(canvas, opts)`) with an **orange E‑IQ
accent mixed into the ramp** (the rest of the UI stays lime — orange is unique to the strands):

```js
window.AncaireWaves.init(canvasEl, {
  bg: '#0a1310',
  ramp: ['#14463d', '#2e8b73', '#cf7a2e', '#f6b85a'], // firm green → orange signal (E‑IQ)
  strands: 20, opacity: 0.55, spread: 0.42, depth: 1.0,
  bleed: 0.45, structure: 0.7, speed: 1.5, glow: 0.45, fps: 30,
});
```

`init` returns a handle with `.stop()`; call it on teardown. It honors `prefers-reduced-motion` (one still
frame) and pauses when the tab is hidden.

---

## Design Tokens

From the Ancaire design system (`ds.css` / `.anc-lab` dark scope). Prefer the CSS variables over hardcoding.

| Token | Value | Use |
|---|---|---|
| `--lime` (on dark) | `#9AD84F` | signal accent, eyebrows, progress, periods |
| off‑white | `#f3f8f1` | primary heading/body text on dark |
| firm line text | `#c9d4cb` | subordinated “Execution, engineered.” |
| `--ink` | `#15201C` | (the “is to use it” closing line base) |
| `--dim` | `#566159` | secondary text, captions |
| `--faint` | `#8B968F` | faintest text |
| `--rule-2` | hairline rule (dark scope) | dividers, borders, grid gaps |
| evergreen | `#14463D` | “Talk to us first” button fill |
| evergreen border | `#2f6e5f` | that button’s border |
| evergreen hover | `#0e3a32` | that button’s hover fill |
| container bg | `#0a1310` | `.anc-lab` background & card fills |
| deepest field | `#060d0a` | handoff gradient end |
| `--ease` | `cubic-bezier(0.2,0.8,0.2,1)` | all transitions |
| `--radius-pill` | pill radius | Skip / pill / Replay |
| button radius | `5px` | primary/custom buttons |

**Type:** **Bricolage Grotesque** (700/800, tracked ‑0.025 to ‑0.035em, line‑height 0.93–0.95) for all
display/headings; **Hanken Grotesk** (400–700) for body, eyebrows, labels, buttons, descriptors; system
**monospace** only for the “Entering automatically…” caption. Loaded from Google Fonts via the DS
`fonts.css` — no self‑hosted fonts. In `ds.css` these are `var(--disp)`, `var(--sans)`, `var(--mono)`.

**Fluid sizes:** H1 `clamp(48px,8.5vw,124px)` (welcome), `clamp(40px,6vw,88px)` (CTA); diptych lines
`clamp(30px,4.4vw,64px)`; register labels `clamp(26px,3vw,42px)`; card titles `clamp(22px,2.2vw,30px)`;
ledes `clamp(15–17px … 19–22px)`. Eyebrows fixed 12–13px.

---

## Assets
- **`assets/waves.js`** — the WebGL wave‑field shader (`window.AncaireWaves`). Included in this bundle;
  in the real site use the existing `waves.js`. **This is the one hard dependency.**
- **`assets/ancaire-logomark-reverse.svg`** — reverse (light‑on‑dark) logomark, used in beat 0 and the
  handoff frame. Included; use the site’s copy in production.
- Fonts: Bricolage Grotesque + Hanken Grotesk (Google Fonts, already loaded by the site’s `ds.css`).
- No other images or icons — arrows are text glyphs (“→”, “↻”), the pause cue is two `<span>` bars.

---

## Integration notes (ancaire.ai site)

1. **This is the entry, `index.html` is the destination.** Serve the intro as the landing route; on finish
   it navigates to the current launch screen. ⚠️ The gate must **not** itself be the file `nextUrl` points
   to, or `finish()` reloads the loop. If `/` is served from `index.html` today, either (a) rename the
   launch screen (e.g. `lab.html`) and set `nextUrl='lab.html'`, serving the intro at `/`; or (b) use the
   overlay pattern: mount the intro over the launch document, set `navigateOnEnd=false`, and remove the
   overlay element in `finish()` to reveal the already‑loaded page.
2. **Suppress the site chrome on the gate.** `ds-chrome.js` auto‑injects nav/footer/search; the intro is
   full‑screen. Either don’t load `ds-chrome.js` on this page, or hide it:
   `header.nav, footer.foot, .nav-scrim, .search-ov { display:none !important; }`.
3. Wrap everything in `class="anc-lab"` so the dark tokens apply; `html,body { margin:0; overflow:hidden; background:#0a1310; }`.
4. **Optional — don’t replay every visit.** Gate on `sessionStorage` so returning visitors skip straight
   in: `if (sessionStorage.getItem('anc_intro_seen')) location.replace(nextUrl);` and set it in `finish()`.
5. Confirm `contactUrl` → `https://ancaire.co/engage.html` (update if engage moves).

---

## Files in this bundle
- `Ancaire Lab Intro.dc.html` — the design reference (all markup, inline styles, copy, timeline, and the
  full controller logic in the trailing `<script>`). Open in a browser to see it run.
- `assets/waves.js` — wave‑field shader dependency.
- `assets/ancaire-logomark-reverse.svg` — logomark used in the reveal + handoff.
- `intro-controller.reference.js` — the framework‑agnostic controller (Section 6), extracted for reference.

---

## 6. Reference controller (framework‑agnostic)

See `intro-controller.reference.js` in this folder for a plain‑JS controller that reproduces the exact
timeline, scene cross‑fades, pause/resume, contact, replay, and handoff behavior described above. Wire it
to static markup that carries these hooks: `#intro-root.anc-lab`, `#intro-canvas`, `#intro-overlay`,
`[data-scene="0".."5"]`, `#intro-progress-fill`, `#intro-paused`, `#intro-pill`, `#intro-handoff`, and
`[data-intro-finish]` / `[data-intro-contact]` / `[data-intro-replay]` on the controls.
