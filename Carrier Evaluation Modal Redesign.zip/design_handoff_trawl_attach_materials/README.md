# Handoff: Trawl Lab — "Attach materials" uploader (two variants)

## Overview
This redesigns the **material-upload region** that sits above the composer in the **Trawl Lab**
AncaireAI console (`ancaire.ai/trawl`). A broker attaches a **broker request list** (required) and
an optional **client application / controls questionnaire** (evaluated as control context), then
asks questions. The current production version drops both upload zones inline as a cramped
two-column block with a heavy boxed warning. This handoff replaces that region with two cleaner
patterns:

- **Variant 01 — Discreet:** the uploader is hidden behind a single "Attach materials" prompt so the
  conversation leads. It opens to a compact inline uploader on demand, and once files are attached it
  collapses to slim file chips.
- **Variant 02 — Expanded:** the full uploader shown at once, but re-laid as a single calm column,
  with the sensitive-material caution demoted to a quiet inline note instead of a boxed alarm.

**Pick ONE to ship** (they are two directions on the same problem — see "Which variant?" below), or
ship Discreet as the default with Expanded as the state after the prompt is opened.

## About the design files
The file in this bundle — `Trawl Upload Modals.dc.html` — is a **design reference written in HTML**.
It is a prototype showing the intended look and behavior, **not production code to paste in**. The
task is to **recreate this design inside the existing `ancaireai-site` codebase** (the Trawl Lab
console shell), using its established components, tokens, and patterns. The prototype hard-codes the
Ancaire Labs design tokens as literal values so it renders standalone; in the real codebase, use the
existing CSS variables (`var(--panel)`, `var(--rule-strong)`, etc.) instead of the literals.

### What is guidance vs. what to build

- **GUIDANCE ONLY — do not change:** the console chrome around the uploader — the teal console
  header (AncaireAI avatar, "AncaireAI / Trawl Lab guide", the `CARRIER EVALUATION` chip, the
  download/expand/minimize/close icon buttons), the conversation log bubbles, the "Read 1 …" pill,
  and the composer row. These already exist in the Trawl Lab shell and are reproduced here **only so
  you can see the uploader in context**. Match whatever the shell already renders; do not restyle it.
- **BUILD THIS — the uploader region and its behavior:** everything between the log and the composer.
  This is the only part being redesigned. Its UI and interaction model (prompt → open → attached) are
  new and should be implemented as described in "Interactions & Behavior".

### ⚠️ Also apply to the other Trawl instances
The **"attach materials" affordance (the paperclip attach button + this uploader pattern) must be
replicated to the Clauses and Policy instances of Trawl as well**, not just Carrier Evaluation.
Trawl runs the same console shell across its evaluation contexts (Carrier Evaluation shown here,
plus Clauses and Policy). The attach button in the composer and the discreet/expanded uploader
should behave identically in those instances — only the copy that names the material types changes
per context. Build the uploader as a shared, context-parameterized component, not a one-off.

## Fidelity
**High-fidelity (hifi).** Colors, typography, spacing, radii, and interaction states are final.
Recreate pixel-for-pixel using the codebase's existing Ancaire Labs component library and tokens.

---

## Screens / Views

Everything lives in one region: the **upload area above the composer** inside the console pane
(the console is ~400px wide in production; the prototype panels are drawn at 472px for legibility).
There are two variants; each has 2–3 states.

### Variant 01 — Discreet
Screenshots: `screenshots/1a-discreet-collapsed.png`, `1a-discreet-open.png`, `1a-discreet-attached.png`

**Purpose:** keep the console conversation-first; the uploader only takes space when the user asks
for it.

**State A — Collapsed (default):** a single full-width **prompt button** sits above the composer.
- Layout: `flex`, `align-items:center`, `gap:11px`, padding `12px 14px`.
- Border `1px dashed var(--rule-strong)`, radius `10px` (`--radius-md`), background `var(--panel-2)`, text `var(--ink-dim)`.
- Left: a `30×30` rounded tile (radius 8px), background `rgba(94,191,180,.14)`, border `1px solid rgba(94,191,180,.4)`, holding a **paperclip icon** (16px, teal `#5EBFB4`).
- Center (stacked): title **"Attach materials to evaluate"** (14px / 600 / `--ink`) over **"Broker request list, and an optional client application"** (12px / `--ink-faint`).
- Right: a chevron-down (16px).
- Hover: border → `#5EBFB4`, text → `--ink`.
- Click → opens State B.

**State B — Open inline uploader (compact):** a bordered sub-panel replaces the prompt.
- Container: border `1px solid var(--rule-strong)`, radius `10px`, background `var(--panel)`.
- Header row: uppercase label **"MATERIALS"** (10.5px / 600 / letter-spacing .14em / `--ink-faint`) + a close (×) button on the right that collapses back to State A.
- **Broker drop zone** (compact, centered, padding `16px 14px`): dashed teal border `1px dashed rgba(94,191,180,.42)`, background `rgba(94,191,180,.05)`, radius `7px`. Teal uppercase kicker "BROKER REQUEST LIST"; line "Drop the broker request tracker, or **choose a file**" (choose-a-file is a teal text button); a **"Paste request list"** pill button (teal accent-outline).
- **Client add (ghost line):** full-width dashed **gold** button "＋ Add client application *optional*" (`1px dashed rgba(224,180,88,.4)`, text `#E0B458`; hover bg `rgba(224,180,88,.08)`).
- Helper line: "Extracted in your browser, never uploaded. One full pass per session; questions stay unlimited." (11.5px / `--ink-faint`).

**State C — Files attached (chips):** compact file chips replace the uploader.
- Broker chip: `flex`, gap 11px, border `1px solid rgba(94,191,180,.4)`, background `rgba(94,191,180,.08)`, radius `10px`, padding `10px 12px`. File-doc icon (20px, teal) + name **"broker-request-tracker.xlsx"** (13.5px/600) over "Broker request list · 182 KB" (11px/`--ink-faint`) + a remove (×) button.
- Client chip: same, in **gold** (`rgba(224,180,88,.42)` border, `rgba(224,180,88,.09)` bg); meta line "Client application · control context · 1.2 MB" in `#a98a47`.
- Below chips: a **one-line caution** with a small warning-triangle icon (13px, gold): "Sensitive material. Confirm the broker or client is aware before you proceed." (11.5px, `#a98a47`).

### Variant 02 — Expanded
Screenshots: `screenshots/1b-expanded-empty.png`, `1b-expanded-attached.png`

**Purpose:** show everything at once but read calmer than today's cramped two-column layout.

**Layout:** single column, `padding:14px`, `gap:18px`. Two sections (Broker, Client) separated by a
`1px var(--rule)` divider.

**Broker section:**
- Header row (space-between): teal uppercase kicker **"BROKER REQUEST LIST"** (10.5px/600/.14em/`#5EBFB4`) + right-aligned uppercase **"REQUIRED"** (`--ink-faint`).
- *Empty:* dashed teal drop zone (padding `22px 18px`, `rgba(94,191,180,.05)` bg, radius 10px): "Drop the broker request tracker here, or **choose a file**"; format line "Word, Excel exported to PDF, .docx, .txt, .md · up to 25 MB · extracted in your browser, never uploaded" (12px/`--ink-faint`); "Paste request list" teal accent-outline pill.
- *Attached:* teal file card (border `rgba(94,191,180,.4)`, bg `rgba(94,191,180,.08)`, radius 10px, padding `13px 14px`): 24px doc icon + "broker-request-tracker.xlsx" (14px/600) over "182 KB · extracted in your browser" + **Replace** text button + remove (×).
- Footer line: "One full pass per session; questions stay unlimited." (11.5px/`--ink-faint`).

**Client section:**
- Header row: gold uppercase kicker **"CLIENT APPLICATION"** (`#E0B458`) + right-aligned **"OPTIONAL · CONTROL CONTEXT"** (`#a98a47`).
- *Empty:* dashed **gold** drop zone (`rgba(224,180,88,.46)` border, `rgba(224,180,88,.05)` bg): "Drop the client application or controls questionnaire, or **choose a file**"; format line "Cyber new-business app, renewal app, privacy supplemental, controls questionnaire · PDF, .docx, .txt, .md · up to 25 MB" (12px/`#a98a47`); "Paste application text" gold accent-outline pill.
- *Attached:* gold file card ("acme-cyber-application.pdf" / "1.2 MB · extracted in your browser") + Replace + remove.
- **Caution (always shown under the client section):** demoted by placement, NOT a boxed alarm. A left gold rule (`2px solid #E0B458`, `padding-left:12px`) with a small warning-triangle icon and the full text: *"Applications and control questionnaires are highly sensitive. Confirm the broker or client is aware you are providing this material to an external tool for review and analysis before you proceed."* (12.5px / line-height 1.55 / color `#c7ab74`).

### Which variant?
- **Discreet** is the recommended default for the console: it protects the conversation-first layout
  and demotes the sensitive-upload path until the user opts in (matches the brand rule "de-emphasis
  by placement, not declaration").
- **Expanded** is the right layout when the uploader should be visible immediately (e.g. an empty
  session with no conversation yet), or as the panel the discreet prompt opens into.
- Simplest production model: **Discreet collapsed by default → clicking the prompt (or the composer
  paperclip) opens the Expanded uploader → attaching files shows the chip/file-card state.**

---

## Interactions & Behavior

**State machine (per Trawl instance):**
```
attached = false, open = false   →  Discreet: collapsed prompt   |  Expanded: empty drop zones
click prompt / composer paperclip →  open = true                 →  inline/expanded uploader
choose-a-file / paste / drop file →  attached = true             →  chips (discreet) / file cards (expanded)
click remove (×) on a file        →  that file cleared; if none left → back to empty/collapsed
click collapse (×) on inline hdr  →  open = false                →  collapsed prompt
```
- **Broker request list is required; client application is optional.** The composer **Send** button
  is disabled (opacity ~.45) until at least the broker list is attached OR the user has typed a
  question. (In the prototype the composer is static; wire real enablement in code.)
- **Drag-and-drop:** each drop zone accepts a file drop; show a hover/drag-over accent state
  (border → solid accent, bg wash one step brighter). Also accept click-to-browse via the
  "choose a file" text button and OS file picker.
- **Paste:** the "Paste request list" / "Paste application text" buttons open a paste affordance
  (textarea or focus the composer with a paste-target) for pasted content instead of a file.
- **Extraction is client-side:** files are parsed in the browser and never uploaded — keep the
  "extracted in your browser, never uploaded" copy accurate to the real behavior.
- **Accepted types:** broker — Word/Excel exported to PDF, `.docx`, `.txt`, `.md`, ≤25 MB;
  client — PDF, `.docx`, `.txt`, `.md`, ≤25 MB.
- **Transitions:** `.16s` on control hovers/borders (matches shell); the inline uploader open/close
  can use a `.22–.3s` height/opacity ease. Honor `prefers-reduced-motion`.
- **Hover states:** text/icon buttons brighten dim→full ink; bordered controls shift border
  `--rule-strong` → accent; filled/pill buttons `filter: brightness(1.08)`.

## State management
Per uploader instance:
- `open: boolean` — inline uploader / expanded panel revealed.
- `brokerFile: File | null` — the required broker request list.
- `clientFile: File | null` — the optional client application.
- Derived: `attached = !!brokerFile || !!clientFile`; `canSend = !!brokerFile || composerText.trim()`.
- `context: 'carrier' | 'clauses' | 'policy'` — drives the material-naming copy (see below). Same
  component, three instances.

## Design tokens
Use the Ancaire Labs tokens already in the codebase; literal values here are for reference only.

**Colors**
- Surface/panels: `--surface #0c1512`, `--panel #11201b`, `--panel-2 #16271f`, `--panel-3 #1b3128`
- Ink: `--ink #e8e4d8`, `--ink-dim #9fb0a4`, `--ink-faint #809086`
- Rules: `--rule rgba(232,228,216,.10)`, `--rule-strong rgba(232,228,216,.18)`
- **Trawl accent (teal):** `#5EBFB4`; washes `rgba(94,191,180,.14)` (soft), `rgba(94,191,180,.08)` (card), `rgba(94,191,180,.05)` (dropzone); borders `rgba(94,191,180,.4)` / `.42` / `.46`
- **Sensitive caution (gold):** `#E0B458`; text-dim `#a98a47`, `#c7ab74` (caution paragraph); washes `rgba(224,180,88,.09)` / `.05`; borders `rgba(224,180,88,.4)`–`.46`
- Console header fill (existing shell): teal gradient `linear-gradient(180deg,#5EBFB4,#4aa89d)` with dark text `#0a120f`

**Typography** — Bricolage Grotesque (`--font-display`) for titles only ("Add your materials", section headings); Hanken Grotesk (`--font-sans`) for everything else.
- Body/composer 16px; message/control 14px; small control 13px; labels 12px / 11px / 10.5px
- Uppercase kickers: 10.5–11px, weight 600, letter-spacing .14em
- Weights 400/500/600/700; tracking `--track-ui .03em`, `--track-label .12em`

**Radius** — `--radius 8px` (buttons/pills-not-full), `--radius-sm 7px`, `--radius-md 10px` (drop zones, chips, cards, composer), `--radius-lg 12px` (bubbles), `--radius-2xl 16px` (panel), `--radius-pill 999px` (chips, prompt tag).

**Shadow** — panel `--shadow-modal 0 30px 90px rgba(0,0,0,.6)`.

**Spacing** — region padding 14px; section gap 18px; control padding ~`10–12px`; drop-zone padding `22px 18px` (expanded) / `16px 14px` (compact).

## Context-specific copy (per Trawl instance)
Keep the shared structure; swap only the material names:
- **Carrier Evaluation** (shown here): broker = "broker request tracker" / "broker request list";
  client = "client application or controls questionnaire" with the cyber-app format list.
- **Clauses** and **Policy**: reuse the same paperclip attach button + uploader; update the two
  material labels and format lists to the terms those instances use. Confirm the exact strings with
  the Trawl product owner — do not invent them.

## Assets
- `assets/ancaire-logomark-reverse.svg` — the reverse (near-white) Ancaire logomark used in the
  console header avatar. This is the real brand mark from the `ancaireai-site` repo
  (`assets/ancaire-logomark-reverse.svg`); use the copy already in the codebase.
- **Icons** are inline stroked SVGs in the house Lucide/Feather style (`viewBox 0 0 24 24`,
  `fill:none`, `currentColor` stroke, ~2.2 weight, round caps/joins) — use the existing `Icon`
  component. Icons used: paperclip (attach), chevron-down, close (×), file-doc, warning-triangle,
  download/expand/minimize/close (header, existing). The paperclip and warning-triangle are outside
  the current `Icon` set — add them in the same stroke style (paths are in the prototype).

## Files
- `Trawl Upload Modals.dc.html` — the full design reference (both variants, all states, the
  interactive prompt→open→attached flow, and the reference console chrome). Open in a browser to
  interact. The state-preview toggle at the top ("Empty / Files attached") is a **demo control only**
  — it is not part of the modal and must not be built.
- `screenshots/` — rendered states:
  - `1a-discreet-collapsed.png`, `1a-discreet-open.png`, `1a-discreet-attached.png`
  - `1b-expanded-empty.png`, `1b-expanded-attached.png`
