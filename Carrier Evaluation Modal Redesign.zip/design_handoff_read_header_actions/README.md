# Handoff: Trawl Lab — "Running read" header action bar (option 2c)

## Overview
Redesign of the action controls in the **left "Running read" panel header** of the Trawl Lab
console (`ancaire.ai/trawl`). Today four full-label buttons (Start a new read, Print this read,
Interactive export, Export questions for broker) share the baseline of the large **Running read**
title and crowd it. The chosen fix — **option 2c** — compresses the three utility actions into a
**compact icon toolbar** (labels on hover) and keeps **Export questions for broker** as the single
labelled, accented primary, sitting to its right. This clears the title and shrinks the control
cluster so it fits a narrow read panel.

## About the design file
`Read Header Actions.dc.html` is a **design reference written in HTML** — a prototype of the intended
look and behavior, not production code to paste in. Recreate it inside the existing `ancaireai-site`
Trawl console using the codebase's own components, tokens, and `Icon` set. The prototype shows the
**Current** (colliding) version and three options (2a / 2b / 2c) stacked; **build 2c only.** The
prototype hard-codes the Ancaire Labs tokens as literals so it renders standalone; in the codebase
use the CSS variables (`var(--panel-2)`, `var(--rule-strong)`, etc.).

### GUIDANCE vs. BUILD
- **Guidance only — do not change:** the panel's kicker ("THE RISK TRANSFER AND INSURANCE ANALYSIS"),
  the `Running read` title, and the description paragraph are reproduced only to show the actions in
  context. Match whatever the panel already renders.
- **Build this:** the header action cluster (top-right of the panel header) and its behavior.

## Fidelity
**High-fidelity.** Colors, type, spacing, radii, and states are final. Recreate exactly with the
existing Ancaire Labs component library and tokens.

---

## The 2c layout

Header is a two-column flex row, **`align-items: flex-start`** (so the control cluster aligns to the
top of the title block, never to the big title's baseline — this is what removes the collision):

- **Left:** kicker + `Running read` title (+ description below the row).
- **Right (control cluster):** a flex row, `align-items:center`, `gap:12px`:
  1. **Icon toolbar** — a single pill-bordered segment (`border:1px solid var(--rule-strong)`,
     `border-radius: var(--radius-pill)`, `overflow:hidden`) holding **three icon-only buttons**
     divided by `1px var(--rule-strong)` separators:
     - **Start a new read** — plus icon
     - **Print this read** — printer icon
     - **Interactive export** — download-arrow icon
     Each button: `36×36`, no individual border (the segment supplies it), color `var(--ink-dim)`,
     background `var(--panel-2)`. **Hover:** color → `var(--ink)`, background → `var(--panel-3)`,
     and a **tooltip** appears below showing the action label.
  2. **Primary** — **Export questions for broker**, a labelled pill: gold text `#E0B458`, background
     `rgba(224,180,88,.1)`, border `1px solid rgba(224,180,88,.55)`, `border-radius: var(--radius-pill)`,
     mail icon + label. **Hover:** background → `rgba(224,180,88,.17)`.

Below the panel in the prototype is a note: hover reveals labels; icon-only relies on recognisable
glyphs, so tooltips are required, not optional.

## Icons (house stroked-SVG style)
Use the existing `Icon` component / house conventions: `viewBox="0 0 24 24"`, `fill:none`,
`stroke:currentColor`, `stroke-width` ~2.1–2.2, round caps/joins. Glyphs:
- **plus** (new read): `M12 5v14 M5 12h14`
- **printer**: `M6 9V3h12v6 M6 18H4a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2` + `rect x=6 y=14 w=12 h=7 rx=1`
- **download** (interactive export): `M12 3v11 M7.5 9.5 12 14l4.5-4.5 M5 20h14`
- **mail** (broker export): `rect x=3 y=5 w=18 h=14 rx=2` + `m3 7 9 6 9-6`
Add plus/printer/download/mail to the `Icon` set in the same stroke style if not present.

## Behavior
- **Icon buttons:** each is a real button with an accessible label. Show the visible tooltip on
  hover AND provide `aria-label` / `title` (keyboard + screen-reader parity). Tooltip: small pill,
  `var(--panel-3)` bg, `1px var(--rule-strong)` border, 6px radius, `0 8px 28px rgba(0,0,0,.5)`
  shadow, appears ~8px below the button, `pointer-events:none`.
- **Actions** keep their current behavior — this is a presentation change only:
  - Start a new read → resets the session/read (confirm if a read is in progress).
  - Print this read → the existing print flow.
  - Interactive export → the existing interactive export.
  - Export questions for broker → the existing broker-questions export (the accented primary).
- **Hover/press:** hover per above; press = color shift, no shrink (house rule). Transitions `.16s`.
  Honor `prefers-reduced-motion`.
- **Responsive:** the cluster stays one row; because it is now ~3 icons + one pill it fits the
  ~400px console panel without wrapping into the title. If the panel is extremely narrow, the primary
  label may truncate before the icon segment does — keep the icon segment intact.

### ⚠️ Apply across all three Trawl modes
These action buttons, exactly as designed in 2c, **must also be applied to the other two Trawl modes:
Clauses, and Clauses + Policy** (the mode shown in the reference is Carrier Evaluation). Build the
header action cluster as **one shared, mode-parameterized component** used by all three modes. The
control set, layout, icons, and the single gold primary are identical across modes; only mode-specific
copy differs where applicable (e.g. the kicker/title text the panel already owns). Do not fork a
separate implementation per mode.

## Design tokens (reference — use codebase variables)
- Panels: `--panel-2 #16271f`, `--panel-3 #1b3128`, `--panel #11201b`
- Ink: `--ink #e8e4d8`, `--ink-dim #9fb0a4`, `--ink-faint #809086`
- Rules: `--rule rgba(232,228,216,.10)`, `--rule-strong rgba(232,228,216,.18)`
- Primary (broker export, gold): text `#E0B458`, bg `rgba(224,180,88,.1)` → hover `.17`, border `rgba(224,180,88,.55)`
- Radius: `--radius-pill 999px` (segment + primary), `6px` tooltip
- Shadow: tooltip `0 8px 28px rgba(0,0,0,.5)`
- Type: Hanken Grotesk; button label 13.5px / 600 / letter-spacing .01em; kicker 11px / 600 / .16em uppercase; title Bricolage Grotesque 30px / 600
- Icon size: 16px in the toolbar, 15px in the primary; button box 36×36

## Files
- `Read Header Actions.dc.html` — the design reference (Current + 2a/2b/2c; **build 2c only**). The
  2b dropdown and other options are for comparison and should not be built.
- `screenshots/2c-header.png` — the chosen layout rendered in context.
